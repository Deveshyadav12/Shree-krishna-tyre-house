use axum::response::Html;

pub async fn dashboard() -> Html<String> {
    let html = r#"
<!DOCTYPE html>
<html lang="en">

<head>

    <meta charset="UTF-8">

    <meta
        name="viewport"
        content="width=device-width, initial-scale=1.0"
    >

    <title>Dashboard | Shri Krishna Tyre House</title>

    <link
        rel="stylesheet"
        href="/assets/css/admin.css"
    >

</head>

<body class="admin-body">

    <aside class="admin-sidebar">

        <div class="admin-brand">

            <div class="admin-logo-mark">
                SK
            </div>

            <div>

                <strong>
                    SHRI KRISHNA
                </strong>

                <small>
                    TYRE HOUSE
                </small>

            </div>

        </div>


        <div class="sidebar-section">

            <span>
                MAIN
            </span>

            <a
                href="/admin"
                class="admin-nav-link active"
            >
                <b>01</b>
                Dashboard
            </a>

            <a
                href="/admin/inventory"
                class="admin-nav-link"
            >
                <b>02</b>
                Tyre Inventory
            </a>

            <a
                href="/admin/services"
                class="admin-nav-link"
            >
                <b>03</b>
                Services
            </a>

            <a
                href="/admin/brands"
                class="admin-nav-link"
            >
                <b>04</b>
                Brands
            </a>

        </div>


        <div class="sidebar-section">

            <span>
                BUSINESS
            </span>

            <a
                href="/admin/customers"
                class="admin-nav-link"
            >
                <b>05</b>
                Customers
            </a>

            <a
                href="/admin/jobs"
                class="admin-nav-link"
            >
                <b>06</b>
                Job Orders
            </a>

            <a
                href="/admin/billing"
                class="admin-nav-link"
            >
                <b>07</b>
                Billing
            </a>

            <a
                href="/admin/invoices"
                class="admin-nav-link"
            >
                <b>08</b>
                Invoices
            </a>

        </div>


        <div class="sidebar-bottom">

            <a
                href="/"
                class="sidebar-bottom-link"
            >
                View Website
            </a>

            <a
                href="/admin/login"
                class="sidebar-bottom-link logout"
            >
                Logout
            </a>

        </div>

    </aside>


    <main class="admin-main">

        <header class="admin-topbar">

            <div>

                <span class="admin-breadcrumb">
                    ADMIN / DASHBOARD
                </span>

                <h2>
                    Dashboard
                </h2>

            </div>


            <div class="admin-online">

                <span class="online-dot"></span>

                ONLINE

            </div>

        </header>


        <section class="admin-content">

            <div class="admin-page-heading">

                <div>

                    <span>
                        OVERVIEW
                    </span>

                    <h1>
                        Business Dashboard
                    </h1>

                    <p>
                        Monitor tyre inventory, jobs,
                        customers and billing.
                    </p>

                </div>


                <a
                    href="/admin/jobs/new"
                    class="admin-primary-button"
                >
                    + New Job Order
                </a>

            </div>


            <div class="stats-grid">


                <div class="stat-card">

                    <div class="stat-label">
                        TYRE INVENTORY
                    </div>

                    <div class="stat-value">
                        126
                    </div>

                    <div class="stat-footer">
                        Products
                    </div>

                </div>


                <div class="stat-card">

                    <div class="stat-label">
                        CUSTOMERS
                    </div>

                    <div class="stat-value">
                        248
                    </div>

                    <div class="stat-footer">
                        Registered
                    </div>

                </div>


                <div class="stat-card">

                    <div class="stat-label">
                        ACTIVE JOBS
                    </div>

                    <div class="stat-value">
                        12
                    </div>

                    <div class="stat-footer">
                        In progress
                    </div>

                </div>


                <div class="stat-card">

                    <div class="stat-label">
                        UNPAID
                    </div>

                    <div class="stat-value">
                        ₹38,450
                    </div>

                    <div class="stat-footer">
                        Pending payments
                    </div>

                </div>

            </div>


            <div class="admin-grid-two">


                <section class="admin-panel">

                    <div class="panel-header">

                        <div>

                            <span>
                                RECENT JOB ORDERS
                            </span>

                            <h2>
                                Latest Work
                            </h2>

                        </div>

                        <a href="/admin/jobs">
                            View All
                        </a>

                    </div>


                    <div class="admin-table-wrapper">

                        <table class="admin-table">

                            <thead>

                                <tr>

                                    <th>
                                        JOB
                                    </th>

                                    <th>
                                        CUSTOMER
                                    </th>

                                    <th>
                                        STATUS
                                    </th>

                                    <th>
                                        TOTAL
                                    </th>

                                </tr>

                            </thead>


                            <tbody>

                                <tr>

                                    <td>
                                        #JOB-1001
                                    </td>

                                    <td>
                                        Walk-in Customer
                                    </td>

                                    <td>
                                        <span class="status progress">
                                            In Progress
                                        </span>
                                    </td>

                                    <td>
                                        ₹8,450
                                    </td>

                                </tr>


                                <tr>

                                    <td>
                                        #JOB-1002
                                    </td>

                                    <td>
                                        Rahul Kumar
                                    </td>

                                    <td>
                                        <span class="status completed">
                                            Completed
                                        </span>
                                    </td>

                                    <td>
                                        ₹12,800
                                    </td>

                                </tr>


                                <tr>

                                    <td>
                                        #JOB-1003
                                    </td>

                                    <td>
                                        Amit Sharma
                                    </td>

                                    <td>
                                        <span class="status pending">
                                            Pending
                                        </span>
                                    </td>

                                    <td>
                                        ₹5,250
                                    </td>

                                </tr>

                            </tbody>

                        </table>

                    </div>

                </section>


                <section class="admin-panel">

                    <div class="panel-header">

                        <div>

                            <span>
                                QUICK ACTIONS
                            </span>

                            <h2>
                                Manage
                            </h2>

                        </div>

                    </div>


                    <div class="quick-actions">

                        <a href="/admin/inventory">
                            <strong>
                                Tyre Inventory
                            </strong>

                            <span>
                                Manage products and stock
                            </span>
                        </a>


                        <a href="/admin/jobs/new">
                            <strong>
                                Create Job Order
                            </strong>

                            <span>
                                Start a new customer job
                            </span>
                        </a>


                        <a href="/admin/billing">
                            <strong>
                                Create Bill
                            </strong>

                            <span>
                                Generate customer billing
                            </span>
                        </a>


                        <a href="/admin/invoices">
                            <strong>
                                Invoices
                            </strong>

                            <span>
                                View generated invoices
                            </span>
                        </a>

                    </div>

                </section>

            </div>

        </section>

    </main>

</body>

</html>
"#;

    Html(html.to_string())
}
