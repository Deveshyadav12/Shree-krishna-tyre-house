use axum::{
    extract::Form,
    response::{Html, Redirect},
};
use serde::Deserialize;

use super::{
    inventory_store::{InventoryItem, inventory_store, next_inventory_id},
    layout::admin_page,
    stock_store::record_movement,
};

#[derive(Deserialize)]
pub struct InventoryForm {
    pub brand: String,
    pub name: String,
    pub size: String,
    pub tyre_type: String,
    pub price: String,
    pub stock: String,
    pub low_stock_limit: String,
}

pub async fn inventory_new() -> Html<String> {
    let content = r#"
        <div class="page-head">

            <div>
                <div class="eyebrow">Inventory Management</div>
                <h1>Add Tyre</h1>
                <p>Add a new tyre product to your inventory.</p>
            </div>

            <a
                href="/admin/inventory"
                class="btn btn-light"
            >
                Back to Inventory
            </a>

        </div>

        <form method="post" action="/admin/inventory/new">

            <div class="inventory-form-layout">

                <section class="panel">

                    <div class="panel-head">
                        <div>
                            <h2>Product Information</h2>
                            <p>Enter the tyre product details.</p>
                        </div>
                    </div>

                    <div class="form-grid">

                        <div class="form-group">
                            <label for="brand">Brand</label>

                            <select
                                id="brand"
                                name="brand"
                                required
                            >
                                <option value="">Select brand</option>
                                <option>MRF</option>
                                <option>CEAT</option>
                                <option>Apollo</option>
                                <option>JK Tyre</option>
                                <option>Michelin</option>
                                <option>Bridgestone</option>
                                <option>Goodyear</option>
                                <option>Yokohama</option>
                                <option>Continental</option>
                                <option>Other</option>
                            </select>
                        </div>

                        <div class="form-group">
                            <label for="name">Tyre Name</label>

                            <input
                                id="name"
                                name="name"
                                type="text"
                                placeholder="Example: MRF ZVTV"
                                required
                            >
                        </div>

                        <div class="form-group">
                            <label for="size">Tyre Size</label>

                            <input
                                id="size"
                                name="size"
                                type="text"
                                placeholder="Example: 185/65 R15"
                                required
                            >
                        </div>

                        <div class="form-group">
                            <label for="tyre_type">Tyre Type</label>

                            <select
                                id="tyre_type"
                                name="tyre_type"
                                required
                            >
                                <option value="">Select type</option>
                                <option>Tubeless</option>
                                <option>Tube Type</option>
                                <option>Run Flat</option>
                                <option>Other</option>
                            </select>
                        </div>

                    </div>

                </section>

                <section class="panel">

                    <div class="panel-head">
                        <div>
                            <h2>Pricing & Stock</h2>
                            <p>Set selling price and opening stock.</p>
                        </div>
                    </div>

                    <div class="form-grid">

                        <div class="form-group">
                            <label for="price">Selling Price</label>

                            <div class="input-prefix">
                                <span>₹</span>

                                <input
                                    id="price"
                                    name="price"
                                    type="number"
                                    min="0"
                                    step="1"
                                    placeholder="6250"
                                    required
                                >
                            </div>
                        </div>

                        <div class="form-group">
                            <label for="stock">Initial Stock</label>

                            <input
                                id="stock"
                                name="stock"
                                type="number"
                                min="0"
                                step="1"
                                placeholder="20"
                                required
                            >
                        </div>

                        <div class="form-group">
                            <label for="low_stock_limit">
                                Low Stock Limit
                            </label>

                            <input
                                id="low_stock_limit"
                                name="low_stock_limit"
                                type="number"
                                min="0"
                                step="1"
                                value="5"
                                required
                            >
                        </div>

                    </div>

                </section>

                <div class="inventory-form-actions">

                    <a
                        href="/admin/inventory"
                        class="btn btn-light"
                    >
                        Cancel
                    </a>

                    <button
                        type="submit"
                        class="btn btn-primary btn-large"
                    >
                        Save Tyre
                    </button>

                </div>

            </div>

        </form>
    "#;

    Html(admin_page("Add Tyre", content))
}

pub async fn create_inventory(Form(form): Form<InventoryForm>) -> Redirect {
    let price = form.price.trim().parse::<u64>().unwrap_or(0);

    let stock = form.stock.trim().parse::<u32>().unwrap_or(0);

    let low_stock_limit = form.low_stock_limit.trim().parse::<u32>().unwrap_or(5);

    let mut inventory = inventory_store().lock().unwrap();

    let id = next_inventory_id(&inventory);

    let tyre_id = id.clone();
    let tyre_name = form.name.trim().to_string();

    inventory.push(InventoryItem {
        id,
        brand: form.brand.trim().to_string(),
        name: tyre_name.clone(),
        size: form.size.trim().to_string(),
        tyre_type: form.tyre_type.trim().to_string(),
        price,
        stock,
        low_stock_limit,
    });

    drop(inventory);

    if stock > 0 {
        record_movement(
            tyre_id,
            tyre_name,
            "STOCK IN".to_string(),
            stock as i32,
            0,
            stock,
            "NEW TYRE".to_string(),
            "Opening stock added.".to_string(),
        );
    }

    Redirect::to("/admin/inventory")
}
