use axum::response::Html;

use super::{layout::admin_page, stock_store::stock_store};

pub async fn stock_history() -> Html<String> {
    let movements = {
        let store = stock_store().lock().unwrap();

        store.clone()
    };

    let rows = movements
        .iter()
        .rev()
        .map(|movement| {
            let quantity_class = if movement.quantity >= 0 {
                "stock-in"
            } else {
                "stock-out"
            };

            let quantity_text = if movement.quantity >= 0 {
                format!("+{}", movement.quantity)
            } else {
                movement.quantity.to_string()
            };

            format!(
                r#"
                <tr>

                    <td>
                        <strong>{}</strong>
                        <span class="table-sub">
                            {}
                        </span>
                    </td>

                    <td>
                        {}
                    </td>

                    <td>
                        <span class="stock-movement {}">
                            {}
                        </span>
                    </td>

                    <td>
                        {}
                    </td>

                    <td>
                        {} → {}
                    </td>

                    <td>
                        {}
                    </td>

                </tr>
                "#,
                movement.tyre_name,
                movement.tyre_id,
                movement.movement_type,
                quantity_class,
                quantity_text,
                movement.reference,
                movement.stock_before,
                movement.stock_after,
                movement.notes
            )
        })
        .collect::<Vec<_>>()
        .join("");

    let content = format!(
        r#"
        <div class="page-head">

            <div>
                <div class="eyebrow">
                    Inventory
                </div>

                <h1>Stock History</h1>

                <p>
                    Track every stock addition, sale and adjustment.
                </p>
            </div>

            <a
                href="/admin/inventory"
                class="btn btn-light"
            >
                Back to Inventory
            </a>

        </div>

        <section class="panel">

            <div class="panel-head">

                <div>
                    <h2>Stock Movements</h2>

                    <p>
                        Complete inventory movement history.
                    </p>
                </div>

            </div>

            <div class="table-wrap">

                <table class="admin-table">

                    <thead>

                        <tr>
                            <th>Tyre</th>
                            <th>Movement</th>
                            <th>Quantity</th>
                            <th>Reference</th>
                            <th>Stock</th>
                            <th>Notes</th>
                        </tr>

                    </thead>

                    <tbody>
                        {}
                    </tbody>

                </table>

            </div>

            {}

        </section>
        "#,
        rows,
        if movements.is_empty() {
            r#"
            <div class="empty-state">
                <p>No stock movements recorded yet.</p>
            </div>
            "#
        } else {
            ""
        }
    );

    Html(admin_page("Stock History", &content))
}
