use std::sync::{Mutex, OnceLock};

use serde::{Deserialize, Serialize};

#[derive(Clone, Debug, Serialize, Deserialize)]
pub struct JobItem {
    pub name: String,
    pub price: u64,
    pub quantity: u32,
    pub item_type: String,
}

#[derive(Clone, Debug)]
pub struct Job {
    pub id: String,
    pub customer: String,
    pub vehicle: String,
    pub vehicle_type: String,
    pub registration: String,
    pub items: Vec<JobItem>,
    pub notes: String,
    pub status: String,
    pub total: u64,

    pub payment_status: String,
    pub payment_method: String,
    pub invoice_id: String,
}

static JOBS: OnceLock<Mutex<Vec<Job>>> = OnceLock::new();

pub fn job_store() -> &'static Mutex<Vec<Job>> {
    JOBS.get_or_init(|| {
        Mutex::new(vec![
            Job {
                id: "JOB-00128".to_string(),
                customer: "Rajesh Kumar".to_string(),
                vehicle: "Maruti Swift".to_string(),
                vehicle_type: "Passenger Car".to_string(),
                registration: "RJ-18-AB-1024".to_string(),
                items: vec![
                    JobItem {
                        name: "MRF ZVTV".to_string(),
                        price: 6250,
                        quantity: 4,
                        item_type: "Tyre".to_string(),
                    },
                    JobItem {
                        name: "Wheel Alignment".to_string(),
                        price: 500,
                        quantity: 1,
                        item_type: "Service".to_string(),
                    },
                ],
                notes: "Replace all four tyres and perform wheel alignment.".to_string(),
                status: "WORK IN PROGRESS".to_string(),
                total: 25500,
                payment_status: "UNPAID".to_string(),
                payment_method: "-".to_string(),
                invoice_id: "-".to_string(),
            },
            Job {
                id: "JOB-00127".to_string(),
                customer: "Mahesh Singh".to_string(),
                vehicle: "Hyundai Creta".to_string(),
                vehicle_type: "SUV".to_string(),
                registration: "RJ-18-CD-2388".to_string(),
                items: vec![
                    JobItem {
                        name: "CEAT Milaze".to_string(),
                        price: 5850,
                        quantity: 4,
                        item_type: "Tyre".to_string(),
                    },
                    JobItem {
                        name: "Wheel Balancing".to_string(),
                        price: 400,
                        quantity: 1,
                        item_type: "Service".to_string(),
                    },
                ],
                notes: "Tyre replacement and balancing.".to_string(),
                status: "NEW".to_string(),
                total: 23800,
                payment_status: "UNPAID".to_string(),
                payment_method: "-".to_string(),
                invoice_id: "-".to_string(),
            },
            Job {
                id: "JOB-00126".to_string(),
                customer: "Anil Sharma".to_string(),
                vehicle: "Tata Nexon".to_string(),
                vehicle_type: "SUV".to_string(),
                registration: "RJ-18-EF-4412".to_string(),
                items: vec![
                    JobItem {
                        name: "Wheel Alignment".to_string(),
                        price: 500,
                        quantity: 1,
                        item_type: "Service".to_string(),
                    },
                    JobItem {
                        name: "Wheel Balancing".to_string(),
                        price: 400,
                        quantity: 1,
                        item_type: "Service".to_string(),
                    },
                ],
                notes: "Alignment and balancing completed.".to_string(),
                status: "COMPLETED".to_string(),
                total: 900,
                payment_status: "UNPAID".to_string(),
                payment_method: "-".to_string(),
                invoice_id: "-".to_string(),
            },
        ])
    })
}

pub fn next_job_id(jobs: &[Job]) -> String {
    let max_number = jobs
        .iter()
        .filter_map(|job| job.id.strip_prefix("JOB-"))
        .filter_map(|number| number.parse::<u32>().ok())
        .max()
        .unwrap_or(0);

    format!("JOB-{:05}", max_number + 1)
}

pub fn next_invoice_id(jobs: &[Job]) -> String {
    let max_number = jobs
        .iter()
        .filter_map(|job| job.invoice_id.strip_prefix("INV-"))
        .filter_map(|number| number.parse::<u32>().ok())
        .max()
        .unwrap_or(0);

    format!("INV-{:05}", max_number + 1)
}
