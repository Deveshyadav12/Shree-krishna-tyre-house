use axum::response::Html;

use super::layout::page;

pub async fn about() -> Html<String> {
    let content = r#"

    <section class="page-hero">

        <div class="container">

            <span class="eyebrow">
                ABOUT US
            </span>

            <h1>
                Built Around Better Driving
            </h1>

            <p>
                Shri Krishna Tyre House provides quality tyres
                and professional tyre and wheel care services
                for everyday drivers.
            </p>

        </div>

    </section>


    <section class="about-preview">

        <div class="container about-grid">

            <div class="about-image">

                <div class="image-placeholder">
                    SHRI KRISHNA<br>
                    TYRE HOUSE
                </div>

            </div>


            <div class="about-content">

                <span class="eyebrow">
                    SHRI KRISHNA TYRE HOUSE
                </span>

                <h2>
                    Quality Tyres.
                    Professional Service.
                </h2>

                <p>
                    We provide tyre products and essential tyre
                    services for customers looking for dependable
                    vehicle care.
                </p>

                <p>
                    Our services include wheel alignment,
                    wheel balancing, tyre replacement,
                    puncture repair, tyre rotation,
                    tubeless repair and other tyre care services.
                </p>

                <p>
                    Our goal is to make tyre selection and
                    vehicle tyre care simple and convenient
                    for our customers.
                </p>

            </div>

        </div>

    </section>


    <section class="section">

        <div class="container">

            <div class="section-heading">

                <div>

                    <span class="eyebrow">
                        WHAT WE FOCUS ON
                    </span>

                    <h2>
                        Professional Tyre Care
                    </h2>

                    <p>
                        Our website and store services are
                        designed around your tyre needs.
                    </p>

                </div>

            </div>


            <div class="service-grid">

                <article class="service-card"
                    style="
                        background:#f8fafc;
                        border-color:#e2e8f0;
                    "
                >

                    <div
                        class="service-icon"
                        style="
                            background:#eff6ff;
                            color:#2563eb;
                        "
                    >
                        01
                    </div>

                    <h3
                        style="color:#0f172a;"
                    >
                        Quality Tyres
                    </h3>

                    <p
                        style="color:#64748b;"
                    >
                        Explore tyre options from
                        multiple recognised brands.
                    </p>

                </article>


                <article class="service-card"
                    style="
                        background:#f8fafc;
                        border-color:#e2e8f0;
                    "
                >

                    <div
                        class="service-icon"
                        style="
                            background:#eff6ff;
                            color:#2563eb;
                        "
                    >
                        02
                    </div>

                    <h3
                        style="color:#0f172a;"
                    >
                        Professional Service
                    </h3>

                    <p
                        style="color:#64748b;"
                    >
                        Tyre and wheel services for
                        everyday vehicle requirements.
                    </p>

                </article>


                <article class="service-card"
                    style="
                        background:#f8fafc;
                        border-color:#e2e8f0;
                    "
                >

                    <div
                        class="service-icon"
                        style="
                            background:#eff6ff;
                            color:#2563eb;
                        "
                    >
                        03
                    </div>

                    <h3
                        style="color:#0f172a;"
                    >
                        Customer Support
                    </h3>

                    <p
                        style="color:#64748b;"
                    >
                        Contact us for tyre information
                        and service enquiries.
                    </p>

                </article>


                <article class="service-card"
                    style="
                        background:#f8fafc;
                        border-color:#e2e8f0;
                    "
                >

                    <div
                        class="service-icon"
                        style="
                            background:#eff6ff;
                            color:#2563eb;
                        "
                    >
                        04
                    </div>

                    <h3
                        style="color:#0f172a;"
                    >
                        Complete Tyre Care
                    </h3>

                    <p
                        style="color:#64748b;"
                    >
                        From inspection and repair to
                        replacement and maintenance.
                    </p>

                </article>

            </div>

        </div>

    </section>


    <section class="contact-strip">

        <div class="container">

            <div class="contact-strip-content">

                <div>

                    <span class="eyebrow">
                        VISIT SHRI KRISHNA TYRE HOUSE
                    </span>

                    <h2>
                        Let's Talk About Your Tyres
                    </h2>

                    <p>
                        Contact our store for tyre information
                        and service enquiries.
                    </p>

                </div>

                <a
                    href="/contact"
                    class="btn btn-light"
                >
                    Contact Us →
                </a>

            </div>

        </div>

    </section>

    "#;

    Html(page("About", content))
}
