use axum::{
    extract::Form,
    response::{Html, Redirect},
};
use serde::Deserialize;

use super::customer_store::{Customer, customer_store, next_customer_id};

#[derive(Deserialize)]
pub struct CustomerForm {
    pub name: String,
    pub phone: String,
    pub email: String,
    pub address: String,
    pub vehicle: String,
    pub registration: String,
}

pub async fn customer_new() -> Html<String> {
    let content = r#"
        <div class="page-head">
            <div>
                <div class="eyebrow">Customer Management</div>
                <h1>Add Customer</h1>
                <p>Create a new customer profile and vehicle record.</p>
            </div>

            <a href="/admin/customers" class="btn btn-light">
                Back to Customers
            </a>
        </div>

        <form method="post" action="/admin/customers/new">

            <div class="customer-form-layout">

                <section class="panel">

                    <div class="panel-head">
                        <div>
                            <h2>Customer Information</h2>
                            <p>Enter the customer's basic contact information.</p>
                        </div>
                    </div>

                    <div class="form-grid">

                        <div class="form-group">
                            <label for="name">Customer Name</label>
                            <input
                                id="name"
                                name="name"
                                type="text"
                                placeholder="Enter customer name"
                                required
                            >
                        </div>

                        <div class="form-group">
                            <label for="phone">Phone Number</label>
                            <input
                                id="phone"
                                name="phone"
                                type="tel"
                                placeholder="9876543210"
                                required
                            >
                        </div>

                        <div class="form-group">
                            <label for="email">Email</label>
                            <input
                                id="email"
                                name="email"
                                type="email"
                                placeholder="customer@example.com"
                            >
                        </div>

                        <div class="form-group form-group-full">
                            <label for="address">Address</label>
                            <textarea
                                id="address"
                                name="address"
                                rows="4"
                                placeholder="Enter customer address"
                            ></textarea>
                        </div>

                    </div>

                </section>

                <section class="panel">

                    <div class="panel-head">
                        <div>
                            <h2>Vehicle Information</h2>
                            <p>Store the customer's primary vehicle.</p>
                        </div>
                    </div>

                    <div class="form-grid">

                        <div class="form-group">
                            <label for="vehicle">Vehicle</label>

                            <select
                                id="vehicle"
                                name="vehicle"
                                required
                            >
                                <option value="">Select vehicle</option>
                                <option>Maruti Swift</option>
                                <option>Hyundai Creta</option>
                                <option>Tata Nexon</option>
                                <option>Mahindra Scorpio</option>
                                <option>Honda Activa</option>
                                <option>Maruti Baleno</option>
                                <option>Hyundai i20</option>
                                <option>Tata Punch</option>
                                <option>Mahindra Thar</option>
                                <option>Honda City</option>
                                <option>Other</option>
                            </select>
                        </div>

                        <div class="form-group">
                            <label for="registration">Registration Number</label>

                            <input
                                id="registration"
                                name="registration"
                                type="text"
                                placeholder="RJ-18-AB-1024"
                                required
                            >
                        </div>

                    </div>

                </section>

                <div class="customer-form-actions">

                    <a
                        href="/admin/customers"
                        class="btn btn-light"
                    >
                        Cancel
                    </a>

                    <button
                        type="submit"
                        class="btn btn-primary btn-large"
                    >
                        Save Customer
                    </button>

                </div>

            </div>

        </form>
    "#;

    Html(super::layout::admin_page("Add Customer", content))
}

pub async fn create_customer(Form(form): Form<CustomerForm>) -> Redirect {
    let mut customers = customer_store().lock().unwrap();

    let id = next_customer_id(&customers);

    customers.push(Customer {
        id,
        name: form.name.trim().to_string(),
        phone: form.phone.trim().to_string(),
        email: form.email.trim().to_string(),
        address: form.address.trim().to_string(),
        vehicle: form.vehicle.trim().to_string(),
        registration: form.registration.trim().to_uppercase(),
    });

    Redirect::to("/admin/customers")
}
