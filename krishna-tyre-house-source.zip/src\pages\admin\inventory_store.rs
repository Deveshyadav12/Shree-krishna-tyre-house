﻿use std::sync::{Mutex, OnceLock};

#[derive(Clone, Debug)]
pub struct InventoryItem {
    pub id: String,
    pub brand: String,
    pub name: String,
    pub size: String,
    pub tyre_type: String,
    pub price: u64,
    pub stock: u32,
    pub low_stock_limit: u32,
}

static INVENTORY: OnceLock<Mutex<Vec<InventoryItem>>> = OnceLock::new();

pub fn inventory_store() -> &'static Mutex<Vec<InventoryItem>> {
    INVENTORY.get_or_init(|| {
        Mutex::new(vec![
            InventoryItem {
                id: "TYR-001".to_string(),
                brand: "MRF".to_string(),
                name: "MRF ZVTV".to_string(),
                size: "185/65 R15".to_string(),
                tyre_type: "Tubeless".to_string(),
                price: 6250,
                stock: 24,
                low_stock_limit: 5,
            },
            InventoryItem {
                id: "TYR-002".to_string(),
                brand: "CEAT".to_string(),
                name: "CEAT Milaze".to_string(),
                size: "175/65 R14".to_string(),
                tyre_type: "Tubeless".to_string(),
                price: 5850,
                stock: 18,
                low_stock_limit: 5,
            },
            InventoryItem {
                id: "TYR-003".to_string(),
                brand: "Apollo".to_string(),
                name: "Apollo Amazer".to_string(),
                size: "195/65 R15".to_string(),
                tyre_type: "Tubeless".to_string(),
                price: 6900,
                stock: 11,
                low_stock_limit: 5,
            },
            InventoryItem {
                id: "TYR-004".to_string(),
                brand: "JK Tyre".to_string(),
                name: "JK Ranger".to_string(),
                size: "215/65 R16".to_string(),
                tyre_type: "Tubeless".to_string(),
                price: 8400,
                stock: 4,
                low_stock_limit: 5,
            },
            InventoryItem {
                id: "TYR-005".to_string(),
                brand: "Michelin".to_string(),
                name: "Michelin Street".to_string(),
                size: "90/90-18".to_string(),
                tyre_type: "Tubeless".to_string(),
                price: 2750,
                stock: 3,
                low_stock_limit: 5,
            },
            InventoryItem {
                id: "TYR-006".to_string(),
                brand: "Bridgestone".to_string(),
                name: "Bridgestone Turanza".to_string(),
                size: "205/55 R16".to_string(),
                tyre_type: "Tubeless".to_string(),
                price: 9250,
                stock: 9,
                low_stock_limit: 5,
            },
        ])
    })
}

pub fn next_inventory_id(items: &[InventoryItem]) -> String {
    let max_number = items
        .iter()
        .filter_map(|item| item.id.strip_prefix("TYR-"))
        .filter_map(|number| number.parse::<u32>().ok())
        .max()
        .unwrap_or(0);

    format!("TYR-{:03}", max_number + 1)
}
