use axum::{
    extract::{Form, Path},
    response::{Html, Redirect},
};
use serde::Deserialize;

use super::{
    inventory_store::inventory_store,
    job_store::{job_store, next_invoice_id},
    layout::admin_page,
    stock_store::record_movement,
};

#[derive(Deserialize)]
pub struct PaymentForm {
    pub payment_method: String,
}

pub async fn billing() -> Html<String> {
    let jobs = {
        let store = job_store().lock().unwrap();
        store.clone()
    };

    let completed_jobs: Vec<_> = jobs
        .iter()
        .filter(|job| job.status == "COMPLETED")
        .cloned()
        .collect();

    let unpaid = completed_jobs
        .iter()
        .filter(|job| job.payment_status == "UNPAID")
        .count();

    let paid = completed_jobs
        .iter()
        .filter(|job| job.payment_status == "PAID")
        .count();

    let pending_amount: u64 = completed_jobs
        .iter()
        .filter(|job| job.payment_status == "UNPAID")
        .map(|job| job.total)
        .sum();

    let rows = completed_jobs
        .iter()
        .map(|job| {
            let status_class = if job.payment_status == "PAID" {
                "status-paid"
            } else {
                "status-unpaid"
            };

            let action = if job.payment_status == "PAID" {
                format!(
                    r#"
                    <a
                        href="/admin/invoices/{}"
                        class="table-action"
                    >
                        View Invoice
                    </a>
                    "#,
                    job.invoice_id
                )
            } else {
                format!(
                    r#"
                    <a
                        href="/admin/billing/{}"
                        class="table-action"
                    >
                        Process Payment
                    </a>
                    "#,
                    job.id
                )
            };

            format!(
                r#"
                <tr>

                    <td>
                        <strong>{}</strong>
                        <span class="table-sub">{}</span>
                    </td>

                    <td>
                        {}
                    </td>

                    <td>
                        ÃƒÂ¢Ã¢â‚¬Å¡Ã‚Â¹{}
                    </td>

                    <td>
                        <span class="status-badge {}">
                            {}
                        </span>
                    </td>

                    <td>
                        {}
                    </td>

                </tr>
                "#,
                job.id,
                job.customer,
                job.vehicle,
                job.total,
                status_class,
                job.payment_status,
                action
            )
        })
        .collect::<Vec<_>>()
        .join("");

    let content = format!(
        r#"
        <div class="page-head">

            <div>
                <div class="eyebrow">
                    Finance
                </div>

                <h1>Billing</h1>

                <p>
                    Process completed jobs and collect payments.
                </p>
            </div>

        </div>

        <div class="billing-stat-grid">

            <div class="billing-stat-card">
                <span>Completed Jobs</span>
                <strong>{}</strong>
            </div>

            <div class="billing-stat-card">
                <span>Pending Payments</span>
                <strong>{}</strong>
            </div>

            <div class="billing-stat-card">
                <span>Paid Jobs</span>
                <strong>{}</strong>
            </div>

            <div class="billing-stat-card">
                <span>Pending Amount</span>
                <strong>ÃƒÂ¢Ã¢â‚¬Å¡Ã‚Â¹{}</strong>
            </div>

        </div>

        <section class="panel">

            <div class="panel-head">

                <div>
                    <h2>Completed Jobs</h2>
                    <p>
                        Payment status for completed workshop jobs.
                    </p>
                </div>

            </div>

            <div class="table-wrap">

                <table class="admin-table">

                    <thead>
                        <tr>
                            <th>Job</th>
                            <th>Vehicle</th>
                            <th>Total</th>
                            <th>Payment</th>
                            <th>Action</th>
                        </tr>
                    </thead>

                    <tbody>
                        {}
                    </tbody>

                </table>

            </div>

        </section>
        "#,
        completed_jobs.len(),
        unpaid,
        paid,
        pending_amount,
        rows
    );

    Html(admin_page("Billing", &content))
}

pub async fn bill_detail(Path(id): Path<String>) -> Html<String> {
    let job = {
        let jobs = job_store().lock().unwrap();

        jobs.iter().find(|job| job.id == id).cloned()
    };

    let content = match job {
        Some(job) => {
            let items = job
                .items
                .iter()
                .map(|item| {
                    let amount = item.price * item.quantity as u64;

                    format!(
                        r#"
                        <tr>
                            <td>{}</td>
                            <td>{}</td>
                            <td>{}</td>
                            <td>ÃƒÂ¢Ã¢â‚¬Å¡Ã‚Â¹{}</td>
                            <td>ÃƒÂ¢Ã¢â‚¬Å¡Ã‚Â¹{}</td>
                        </tr>
                        "#,
                        item.name, item.item_type, item.quantity, item.price, amount
                    )
                })
                .collect::<Vec<_>>()
                .join("");

            if job.payment_status == "PAID" {
                format!(
                    r#"
                    <div class="page-head">

                        <div>
                            <div class="eyebrow">Billing</div>
                            <h1>Payment Complete</h1>
                            <p>{}</p>
                        </div>

                        <a
                            href="/admin/invoices/{}"
                            class="btn btn-primary"
                        >
                            View Invoice
                        </a>

                    </div>

                    <section class="panel">

                        <div class="payment-success">
                            <div class="payment-success-icon">
                                ÃƒÂ¢Ã…â€œÃ¢â‚¬Å“
                            </div>

                            <div>
                                <strong>
                                    Payment received
                                </strong>

                                <span>
                                    {} paid ÃƒÂ¢Ã¢â‚¬Å¡Ã‚Â¹{} using {}.
                                </span>
                            </div>
                        </div>

                    </section>
                    "#,
                    job.id, job.invoice_id, job.customer, job.total, job.payment_method
                )
            } else {
                format!(
                    r#"
                    <div class="page-head">

                        <div>
                            <div class="eyebrow">Billing</div>

                            <h1>Process Payment</h1>

                            <p>
                                Job {} Ãƒâ€šÃ‚Â· {}
                            </p>
                        </div>

                        <a
                            href="/admin/billing"
                            class="btn btn-light"
                        >
                            Back to Billing
                        </a>

                    </div>

                    <section class="panel">

                        <div class="billing-customer-strip">

                            <div>
                                <span>Customer</span>
                                <strong>{}</strong>
                            </div>

                            <div>
                                <span>Vehicle</span>
                                <strong>{}</strong>
                            </div>

                            <div>
                                <span>Registration</span>
                                <strong>{}</strong>
                            </div>

                        </div>

                    </section>

                    <section class="panel">

                        <div class="panel-head">
                            <div>
                                <h2>Bill Items</h2>
                                <p>Items included in this job.</p>
                            </div>
                        </div>

                        <div class="table-wrap">

                            <table class="admin-table">

                                <thead>
                                    <tr>
                                        <th>Item</th>
                                        <th>Type</th>
                                        <th>Qty</th>
                                        <th>Price</th>
                                        <th>Total</th>
                                    </tr>
                                </thead>

                                <tbody>
                                    {}
                                </tbody>

                            </table>

                        </div>

                        <div class="bill-grand-total">
                            <span>Grand Total</span>
                            <strong>ÃƒÂ¢Ã¢â‚¬Å¡Ã‚Â¹{}</strong>
                        </div>

                    </section>

                    <section class="panel">

                        <div class="panel-head">

                            <div>
                                <h2>Payment Method</h2>
                                <p>Select how the customer paid.</p>
                            </div>

                        </div>

                        <form
                            method="post"
                            action="/admin/billing/{}/pay"
                        >

                            <div class="payment-method-grid">

                                <label class="payment-method-card">

                                    <input
                                        type="radio"
                                        name="payment_method"
                                        value="Cash"
                                        checked
                                    >

                                    <span>
                                        <strong>Cash</strong>
                                        <small>
                                            Cash payment
                                        </small>
                                    </span>

                                </label>

                                <label class="payment-method-card">

                                    <input
                                        type="radio"
                                        name="payment_method"
                                        value="UPI"
                                    >

                                    <span>
                                        <strong>UPI</strong>
                                        <small>
                                            UPI payment
                                        </small>
                                    </span>

                                </label>

                                <label class="payment-method-card">

                                    <input
                                        type="radio"
                                        name="payment_method"
                                        value="Card"
                                    >

                                    <span>
                                        <strong>Card</strong>
                                        <small>
                                            Card payment
                                        </small>
                                    </span>

                                </label>

                            </div>

                            <button
                                type="submit"
                                class="btn btn-primary btn-large payment-submit"
                            >
                                Mark as Paid Ãƒâ€šÃ‚Â· ÃƒÂ¢Ã¢â‚¬Å¡Ã‚Â¹{}
                            </button>

                        </form>

                    </section>
                    "#,
                    job.id,
                    job.customer,
                    job.customer,
                    job.vehicle,
                    job.registration,
                    items,
                    job.total,
                    job.id,
                    job.total
                )
            }
        }

        None => r#"
            <section class="panel empty-state">

                <h2>Bill Not Found</h2>

                <p>
                    The requested job could not be found.
                </p>

                <a
                    href="/admin/billing"
                    class="btn btn-primary"
                >
                    Back to Billing
                </a>

            </section>
        "#
        .to_string(),
    };

    Html(admin_page("Billing", &content))
}

pub async fn process_payment(Path(id): Path<String>, Form(form): Form<PaymentForm>) -> Redirect {
    let (invoice_id, job_items);

    {
        let mut jobs = job_store().lock().unwrap();

        let job_index = match jobs.iter().position(|job| job.id == id) {
            Some(index) => index,
            None => return Redirect::to("/admin/billing"),
        };

        if jobs[job_index].status != "COMPLETED" {
            return Redirect::to(&format!("/admin/billing/{}", id));
        }

        if jobs[job_index].payment_status == "PAID" {
            return Redirect::to(&format!("/admin/billing/{}", id));
        }

        let new_invoice_id = next_invoice_id(&jobs);

        job_items = jobs[job_index].items.clone();

        jobs[job_index].payment_status = "PAID".to_string();
        jobs[job_index].payment_method = form.payment_method.clone();
        jobs[job_index].invoice_id = new_invoice_id.clone();

        invoice_id = new_invoice_id;
    }

    for job_item in &job_items {
        if job_item.item_type != "Tyre" {
            continue;
        }

        let movement = {
            let mut inventory = inventory_store().lock().unwrap();

            if let Some(tyre) = inventory.iter_mut().find(|item| item.name == job_item.name) {
                if tyre.stock >= job_item.quantity {
                    let tyre_id = tyre.id.clone();
                    let tyre_name = tyre.name.clone();
                    let stock_before = tyre.stock;

                    tyre.stock -= job_item.quantity;

                    Some((tyre_id, tyre_name, stock_before, tyre.stock))
                } else {
                    None
                }
            } else {
                None
            }
        };

        if let Some((tyre_id, tyre_name, stock_before, stock_after)) = movement {
            record_movement(
                tyre_id,
                tyre_name,
                "STOCK OUT".to_string(),
                -(job_item.quantity as i32),
                stock_before,
                stock_after,
                id.clone(),
                format!("Tyre issued for invoice {}.", invoice_id),
            );
        }
    }

    Redirect::to(&format!("/admin/invoices/{}", invoice_id))
}
