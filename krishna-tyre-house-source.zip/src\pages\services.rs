use axum::response::Html;

use super::layout::page;

pub async fn services() -> Html<String> {
    let services = vec![
        (
            "01",
            "Wheel Alignment",
            "Correct wheel angles to improve handling, tyre life and driving stability.",
        ),
        (
            "02",
            "Wheel Balancing",
            "Balance your wheels to reduce vibration and provide a smoother drive.",
        ),
        (
            "03",
            "Tyre Replacement",
            "Replace worn or damaged tyres with suitable tyre options for your vehicle.",
        ),
        (
            "04",
            "Puncture Repair",
            "Professional puncture inspection and repair for suitable tyre damage.",
        ),
        (
            "05",
            "Tyre Rotation",
            "Rotate tyres to help maintain more even tread wear across the vehicle.",
        ),
        (
            "06",
            "Tubeless Repair",
            "Repair suitable tubeless tyre punctures and restore normal tyre operation.",
        ),
        (
            "07",
            "Nitrogen Inflation",
            "Nitrogen inflation service for customers who prefer nitrogen-filled tyres.",
        ),
        (
            "08",
            "Wheel Care",
            "General wheel and tyre care to help maintain reliable vehicle performance.",
        ),
    ];

    let mut service_cards = String::new();

    for (number, name, description) in services {
        service_cards.push_str(&format!(
            r#"
            <article class="large-service-card">

                <div class="large-service-icon">
                    {number}
                </div>

                <span class="eyebrow">
                    TYRE SERVICE
                </span>

                <h2>
                    {name}
                </h2>

                <p>
                    {description}
                </p>

                <strong>
                    PROFESSIONAL SERVICE
                </strong>

            </article>
            "#
        ));
    }

    let content = format!(
        r#"

        <section class="page-hero">

            <div class="container">

                <span class="eyebrow">
                    OUR SERVICES
                </span>

                <h1>
                    Professional Tyre Care
                </h1>

                <p>
                    From tyre replacement to wheel alignment,
                    we provide essential tyre and wheel services
                    for your vehicle.
                </p>

            </div>

        </section>


        <section class="section">

            <div class="container">

                <div class="section-heading">

                    <div>

                        <span class="eyebrow">
                            WHAT WE DO
                        </span>

                        <h2>
                            Tyre & Wheel Services
                        </h2>

                        <p>
                            Choose the service your vehicle needs.
                        </p>

                    </div>

                </div>


                <div class="service-list-grid">

                    {}

                </div>

            </div>

        </section>


        <section class="section section-dark">

            <div class="container">

                <div class="section-heading">

                    <div>

                        <span class="eyebrow">
                            COMPLETE TYRE CARE
                        </span>

                        <h2>
                            Everything Your Tyres Need
                        </h2>

                        <p>
                            Keep your vehicle ready for everyday
                            driving with professional tyre care.
                        </p>

                    </div>

                </div>


                <div class="service-grid">

                    <article class="service-card">

                        <div class="service-icon">
                            01
                        </div>

                        <h3>
                            Inspection
                        </h3>

                        <p>
                            Check tyre condition, tread and
                            visible damage.
                        </p>

                    </article>


                    <article class="service-card">

                        <div class="service-icon">
                            02
                        </div>

                        <h3>
                            Installation
                        </h3>

                        <p>
                            Professional tyre installation
                            for suitable applications.
                        </p>

                    </article>


                    <article class="service-card">

                        <div class="service-icon">
                            03
                        </div>

                        <h3>
                            Alignment
                        </h3>

                        <p>
                            Wheel alignment service for
                            improved vehicle stability.
                        </p>

                    </article>


                    <article class="service-card">

                        <div class="service-icon">
                            04
                        </div>

                        <h3>
                            Maintenance
                        </h3>

                        <p>
                            Regular tyre care helps maintain
                            reliable performance.
                        </p>

                    </article>

                </div>

            </div>

        </section>


        <section class="contact-strip">

            <div class="container">

                <div class="contact-strip-content">

                    <div>

                        <span class="eyebrow">
                            NEED TYRE SERVICE?
                        </span>

                        <h2>
                            Talk To Shri Krishna Tyre House
                        </h2>

                        <p>
                            Contact us for tyre information
                            and service enquiries.
                        </p>

                    </div>

                    <a
                        href="/contact"
                        class="btn btn-light"
                    >
                        Contact Us →
                    </a>

                </div>

            </div>

        </section>

        "#,
        service_cards
    );

    Html(page("Services", &content))
}
