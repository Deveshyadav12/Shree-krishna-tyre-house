use axum::response::Html;

use super::layout::page;

pub async fn tyres() -> Html<String> {
    let products = vec![
        (
            "1",
            "MRF",
            "MRF ZVTV",
            "185/65 R15",
            "Passenger Car",
            "₹6,250",
            "Available",
        ),
        (
            "2",
            "CEAT",
            "CEAT Milaze",
            "175/65 R14",
            "Passenger Car",
            "₹5,850",
            "Available",
        ),
        (
            "3",
            "Apollo",
            "Apollo Amazer",
            "195/65 R15",
            "Passenger Car",
            "₹6,900",
            "Available",
        ),
        (
            "4",
            "JK Tyre",
            "JK Ranger",
            "215/65 R16",
            "SUV",
            "₹8,400",
            "Available",
        ),
        (
            "5",
            "Michelin",
            "Michelin Street",
            "90/90-18",
            "Motorcycle",
            "₹2,750",
            "Available",
        ),
        (
            "6",
            "Bridgestone",
            "Bridgestone Turanza",
            "205/55 R16",
            "Passenger Car",
            "₹9,250",
            "Available",
        ),
    ];

    let mut product_cards = String::new();

    for (id, brand, name, size, vehicle, price, stock) in products {
        product_cards.push_str(&format!(
            r#"
            <article class="product-card">

                <div class="product-image">

                    <div class="tyre-placeholder">
                        TYRE
                    </div>

                </div>

                <div class="product-content">

                    <div class="product-brand">
                        {brand}
                    </div>

                    <h3>
                        {name}
                    </h3>

                    <p>
                        {vehicle}
                    </p>

                    <div class="product-meta">

                        <span>
                            Size: {size}
                        </span>

                        <strong>
                            {price}
                        </strong>

                    </div>

                    <div style="
                        margin-top:10px;
                        color:#16a34a;
                        font-size:12px;
                        font-weight:700;
                    ">
                        ● {stock}
                    </div>

                    <a
                        href="/tyres/{id}"
                        class="product-button"
                    >
                        View Tyre Details →
                    </a>

                </div>

            </article>
            "#
        ));
    }

    let content = format!(
        r#"

        <section class="page-hero">

            <div class="container">

                <span class="eyebrow">
                    TYRE CATALOGUE
                </span>

                <h1>
                    Find The Right Tyres
                </h1>

                <p>
                    Explore tyre options for cars,
                    SUVs and motorcycles.
                </p>

            </div>

        </section>


        <section class="section">

            <div class="container">

                <div class="filter-panel">

                    <div class="search-field">

                        <label for="vehicleType">
                            Vehicle Type
                        </label>

                        <select id="vehicleType">

                            <option value="">
                                All Vehicles
                            </option>

                            <option value="Passenger Car">
                                Passenger Car
                            </option>

                            <option value="SUV">
                                SUV
                            </option>

                            <option value="Motorcycle">
                                Motorcycle
                            </option>

                        </select>

                    </div>


                    <div class="search-field">

                        <label for="tyreSize">
                            Tyre Size
                        </label>

                        <input
                            id="tyreSize"
                            type="text"
                            placeholder="Example: 185/65 R15"
                        >

                    </div>


                    <div class="search-field">

                        <label for="brand">
                            Brand
                        </label>

                        <select id="brand">

                            <option value="">
                                All Brands
                            </option>

                            <option value="MRF">
                                MRF
                            </option>

                            <option value="CEAT">
                                CEAT
                            </option>

                            <option value="Apollo">
                                Apollo
                            </option>

                            <option value="JK Tyre">
                                JK Tyre
                            </option>

                            <option value="Michelin">
                                Michelin
                            </option>

                            <option value="Bridgestone">
                                Bridgestone
                            </option>

                        </select>

                    </div>


                    <button
                        type="button"
                        id="searchTyres"
                        class="btn btn-primary"
                    >
                        Search Tyres
                    </button>

                </div>


                <div class="catalog-header">

                    <div>

                        <span class="eyebrow">
                            OUR PRODUCTS
                        </span>

                        <h2>
                            Available Tyres
                        </h2>

                    </div>

                    <span>
                        {} tyre products
                    </span>

                </div>


                <div class="product-grid">

                    {}

                </div>

            </div>

        </section>


        <section class="contact-strip">

            <div class="container">

                <div class="contact-strip-content">

                    <div>

                        <span class="eyebrow">
                            NEED HELP?
                        </span>

                        <h2>
                            Not Sure Which Tyre To Choose?
                        </h2>

                        <p>
                            Contact Shri Krishna Tyre House
                            for tyre information and service support.
                        </p>

                    </div>

                    <a
                        href="/contact"
                        class="btn btn-light"
                    >
                        Contact Us →
                    </a>

                </div>

            </div>

        </section>

        "#,
        6, product_cards
    );

    Html(page("Tyres", &content))
}

use axum::extract::Path;

pub async fn tyre_detail(Path(id): Path<String>) -> Html<String> {
    let content = format!(
        r#"

        <section class="page-hero">

            <div class="container">

                <span class="eyebrow">
                    TYRE DETAILS
                </span>

                <h1>
                    Tyre Product #{}
                </h1>

                <p>
                    Product information from
                    Shri Krishna Tyre House.
                </p>

            </div>

        </section>


        <section class="section">

            <div class="container">

                <div class="product-detail">

                    <div class="product-detail-image">

                        <div class="tyre-placeholder">
                            TYRE
                        </div>

                    </div>


                    <div class="product-detail-info">

                        <span class="eyebrow">
                            MRF
                        </span>

                        <h1>
                            MRF ZVTV
                        </h1>

                        <p class="product-detail-description">
                            Quality tyre option for
                            everyday passenger vehicle
                            driving.
                        </p>

                        <div class="product-detail-price">
                            ₹6,250
                        </div>


                        <div class="product-specs">

                            <div class="spec-item">

                                <small>
                                    Tyre Size
                                </small>

                                <strong>
                                    185/65 R15
                                </strong>

                            </div>


                            <div class="spec-item">

                                <small>
                                    Vehicle
                                </small>

                                <strong>
                                    Passenger Car
                                </strong>

                            </div>


                            <div class="spec-item">

                                <small>
                                    Brand
                                </small>

                                <strong>
                                    MRF
                                </strong>

                            </div>


                            <div class="spec-item">

                                <small>
                                    Availability
                                </small>

                                <strong>
                                    Available
                                </strong>

                            </div>

                        </div>


                        <div class="hero-actions">

                            <a
                                href="/contact"
                                class="btn btn-primary"
                            >
                                Contact Store
                            </a>

                            <a
                                href="/tyres"
                                class="btn"
                                style="
                                    border:1px solid #e2e8f0;
                                    background:#fff;
                                "
                            >
                                Back To Tyres
                            </a>

                        </div>

                    </div>

                </div>

            </div>

        </section>

        "#,
        id
    );

    Html(page("Tyre Details", &content))
}
