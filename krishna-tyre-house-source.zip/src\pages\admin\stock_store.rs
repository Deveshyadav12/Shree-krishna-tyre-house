use std::sync::{Mutex, OnceLock};

#[derive(Clone, Debug)]
pub struct StockMovement {
    pub id: String,
    pub tyre_id: String,
    pub tyre_name: String,
    pub movement_type: String,
    pub quantity: i32,
    pub stock_before: u32,
    pub stock_after: u32,
    pub reference: String,
    pub notes: String,
}

static STOCK_MOVEMENTS: OnceLock<Mutex<Vec<StockMovement>>> = OnceLock::new();

pub fn stock_store() -> &'static Mutex<Vec<StockMovement>> {
    STOCK_MOVEMENTS.get_or_init(|| Mutex::new(Vec::new()))
}

pub fn next_stock_movement_id(movements: &[StockMovement]) -> String {
    let max_number = movements
        .iter()
        .filter_map(|movement| movement.id.strip_prefix("STK-"))
        .filter_map(|number| number.parse::<u32>().ok())
        .max()
        .unwrap_or(0);

    format!("STK-{:05}", max_number + 1)
}

pub fn record_movement(
    tyre_id: String,
    tyre_name: String,
    movement_type: String,
    quantity: i32,
    stock_before: u32,
    stock_after: u32,
    reference: String,
    notes: String,
) {
    let mut movements = stock_store().lock().unwrap();

    let id = next_stock_movement_id(&movements);

    movements.push(StockMovement {
        id,
        tyre_id,
        tyre_name,
        movement_type,
        quantity,
        stock_before,
        stock_after,
        reference,
        notes,
    });
}
