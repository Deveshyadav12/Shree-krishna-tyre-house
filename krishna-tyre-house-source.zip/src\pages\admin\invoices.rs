use axum::{extract::Path, response::Html};

use super::{job_store::job_store, layout::admin_page};

pub async fn invoices() -> Html<String> {
    let jobs = job_store().lock().unwrap().clone();

    let paid_jobs: Vec<_> = jobs
        .iter()
        .filter(|job| job.payment_status == "PAID")
        .collect();

    let total_invoices = paid_jobs.len();

    let total_amount = paid_jobs.iter().map(|job| job.total).sum::<u64>();

    let mut rows = String::new();

    for job in paid_jobs.iter().rev() {
        rows.push_str(&format!(
            r#"
<tr>

    <td>
        <a
            href="/admin/invoices/{invoice}"
            class="invoice-id-link"
        >
            {invoice}
        </a>
    </td>

    <td>
        <div class="job-customer-cell">
            <strong>{customer}</strong>
            <small>{registration}</small>
        </div>
    </td>

    <td>
        <div class="job-customer-cell">
            <strong>{vehicle}</strong>
            <small>{vehicle_type}</small>
        </div>
    </td>

    <td>
        <strong>₹{total}</strong>
    </td>

    <td>
        <span class="invoice-payment-status">
            {payment_method}
        </span>
    </td>

    <td>
        <a
            href="/admin/invoices/{invoice}"
            class="job-view-button"
        >
            View
        </a>
    </td>

</tr>
"#,
            invoice = job.invoice_id,
            customer = job.customer,
            registration = job.registration,
            vehicle = job.vehicle,
            vehicle_type = job.vehicle_type,
            total = job.total,
            payment_method = job.payment_method,
        ));
    }

    let content = format!(
        r#"
<div class="admin-page-header">

    <div>

        <div class="admin-eyebrow">
            FINANCE
        </div>

        <h1>Invoices</h1>

        <p>
            View paid invoices and customer receipts.
        </p>

    </div>

</div>


<div class="invoice-stat-grid">

    <div class="invoice-stat-card">

        <span>
            Total Invoices
        </span>

        <strong>
            {total_invoices}
        </strong>

    </div>


    <div class="invoice-stat-card">

        <span>
            Total Billed
        </span>

        <strong>
            ₹{total_amount}
        </strong>

    </div>

</div>


<div class="admin-panel">

    <div class="job-admin-toolbar">

        <input
            type="search"
            class="admin-search-input"
            placeholder="Search invoice, customer or vehicle..."
        >

        <a
            href="/admin/billing"
            class="admin-secondary-button"
        >
            Billing
        </a>

    </div>


    <div class="job-admin-table-wrap">

        <table class="job-admin-table">

            <thead>

                <tr>

                    <th>
                        Invoice
                    </th>

                    <th>
                        Customer
                    </th>

                    <th>
                        Vehicle
                    </th>

                    <th>
                        Amount
                    </th>

                    <th>
                        Payment
                    </th>

                    <th>
                        Action
                    </th>

                </tr>

            </thead>


            <tbody>

                {rows}

            </tbody>

        </table>

    </div>

</div>
"#,
        total_invoices = total_invoices,
        total_amount = total_amount,
        rows = rows,
    );

    Html(admin_page("Invoices", &content))
}

pub async fn invoice_detail(Path(invoice_id): Path<String>) -> Html<String> {
    let job = {
        let jobs = job_store().lock().unwrap();

        jobs.iter()
            .find(|job| job.invoice_id == invoice_id)
            .cloned()
    };

    let Some(job) = job else {
        return Html(admin_page(
            "Invoices",
            r#"
<div class="admin-page-header">

    <div>

        <div class="admin-eyebrow">
            INVOICE
        </div>

        <h1>Invoice Not Found</h1>

        <p>
            The requested invoice does not exist.
        </p>

    </div>

</div>


<div class="admin-panel">

    <a
        href="/admin/invoices"
        class="admin-secondary-button"
    >
        Back to Invoices
    </a>

</div>
"#,
        ));
    };

    let mut item_rows = String::new();

    for item in &job.items {
        let subtotal = item.price * item.quantity as u64;

        item_rows.push_str(&format!(
            r#"
<tr>

    <td>
        {name}
    </td>

    <td>
        {item_type}
    </td>

    <td>
        {quantity}
    </td>

    <td>
        ₹{price}
    </td>

    <td>
        <strong>
            ₹{subtotal}
        </strong>
    </td>

</tr>
"#,
            name = item.name,
            item_type = item.item_type,
            quantity = item.quantity,
            price = item.price,
            subtotal = subtotal,
        ));
    }

    let invoice_html = format!(
        r#"
<div class="invoice-page">

    <div class="invoice-toolbar no-print">

        <a
            href="/admin/invoices"
            class="admin-secondary-button"
        >
            Back
        </a>

        <button
            type="button"
            class="invoice-print-button"
            onclick="window.print()"
        >
            Print Invoice
        </button>

    </div>


    <div class="invoice-document">

        <div class="invoice-header">

            <div>

                <div class="invoice-company-mark">
                    SK
                </div>

                <div class="invoice-company">

                    <strong>
                        SHRI KRISHNA TYRE HOUSE
                    </strong>

                    <span>
                        Tyres & Auto Care
                    </span>

                </div>

            </div>


            <div class="invoice-title">

                <span>
                    INVOICE
                </span>

                <strong>
                    {invoice_id}
                </strong>

            </div>

        </div>


        <div class="invoice-divider"></div>


        <div class="invoice-meta-grid">

            <div>

                <span>
                    CUSTOMER
                </span>

                <strong>
                    {customer}
                </strong>

                <small>
                    {registration}
                </small>

            </div>


            <div>

                <span>
                    VEHICLE
                </span>

                <strong>
                    {vehicle}
                </strong>

                <small>
                    {vehicle_type}
                </small>

            </div>


            <div>

                <span>
                    JOB ORDER
                </span>

                <strong>
                    {job_id}
                </strong>

            </div>


            <div>

                <span>
                    PAYMENT
                </span>

                <strong class="invoice-paid">
                    PAID
                </strong>

                <small>
                    {payment_method}
                </small>

            </div>

        </div>


        <div class="invoice-table-wrap">

            <table class="invoice-table">

                <thead>

                    <tr>

                        <th>
                            #
                        </th>

                        <th>
                            Description
                        </th>

                        <th>
                            Type
                        </th>

                        <th>
                            Qty
                        </th>

                        <th>
                            Rate
                        </th>

                        <th>
                            Amount
                        </th>

                    </tr>

                </thead>


                <tbody>

                    {invoice_items}

                </tbody>

            </table>

        </div>


        <div class="invoice-total-section">

            <div class="invoice-total-label">
                Total Amount
            </div>

            <div class="invoice-total-value">
                ₹{total}
            </div>

        </div>


        <div class="invoice-paid-box">

            <strong>
                PAYMENT RECEIVED
            </strong>

            <span>
                Payment method: {payment_method}
            </span>

            <span>
                Invoice status: PAID
            </span>

        </div>


        <div class="invoice-footer">

            <div>

                <strong>
                    Thank you for choosing
                    Shri Krishna Tyre House.
                </strong>

                <span>
                    Please keep this invoice
                    for your records.
                </span>

            </div>


            <div class="invoice-footer-right">

                <strong>
                    PAID
                </strong>

                <span>
                    {invoice_id}
                </span>

            </div>

        </div>

    </div>

</div>

<script>
document.title = "{invoice_id} | Shri Krishna Tyre House";
</script>
"#,
        invoice_id = job.invoice_id,
        customer = job.customer,
        registration = job.registration,
        vehicle = job.vehicle,
        vehicle_type = job.vehicle_type,
        job_id = job.id,
        payment_method = job.payment_method,
        total = job.total,
        invoice_items = build_invoice_items(&job.items),
    );

    Html(admin_page("Invoices", &invoice_html))
}

fn build_invoice_items(items: &[super::job_store::JobItem]) -> String {
    let mut html = String::new();

    for (index, item) in items.iter().enumerate() {
        let subtotal = item.price * item.quantity as u64;

        html.push_str(&format!(
            r#"
<tr>

    <td>
        {}
    </td>

    <td>
        <strong>
            {}
        </strong>
    </td>

    <td>
        {}
    </td>

    <td>
        {}
    </td>

    <td>
        ₹{}
    </td>

    <td>
        <strong>
            ₹{}
        </strong>
    </td>

</tr>
"#,
            index + 1,
            item.name,
            item.item_type,
            item.quantity,
            item.price,
            subtotal,
        ));
    }

    html
}
