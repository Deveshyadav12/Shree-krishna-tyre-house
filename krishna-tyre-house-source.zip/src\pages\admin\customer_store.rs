use std::sync::{Mutex, OnceLock};

#[derive(Clone, Debug)]
pub struct Customer {
    pub id: String,
    pub name: String,
    pub phone: String,
    pub email: String,
    pub address: String,
    pub vehicle: String,
    pub registration: String,
}

static CUSTOMERS: OnceLock<Mutex<Vec<Customer>>> = OnceLock::new();

pub fn customer_store() -> &'static Mutex<Vec<Customer>> {
    CUSTOMERS.get_or_init(|| {
        Mutex::new(vec![
            Customer {
                id: "CUS-001".to_string(),
                name: "Rajesh Kumar".to_string(),
                phone: "9876543210".to_string(),
                email: "rajesh@example.com".to_string(),
                address: "Buhana, Jhunjhunu".to_string(),
                vehicle: "Maruti Swift".to_string(),
                registration: "RJ-18-AB-1024".to_string(),
            },
            Customer {
                id: "CUS-002".to_string(),
                name: "Mahesh Singh".to_string(),
                phone: "9829012345".to_string(),
                email: "mahesh@example.com".to_string(),
                address: "Singhana, Jhunjhunu".to_string(),
                vehicle: "Hyundai Creta".to_string(),
                registration: "RJ-18-CD-2388".to_string(),
            },
            Customer {
                id: "CUS-003".to_string(),
                name: "Anil Sharma".to_string(),
                phone: "9812345678".to_string(),
                email: "anil@example.com".to_string(),
                address: "Buhana, Rajasthan".to_string(),
                vehicle: "Tata Nexon".to_string(),
                registration: "RJ-18-EF-4412".to_string(),
            },
        ])
    })
}

pub fn next_customer_id(customers: &[Customer]) -> String {
    let max_number = customers
        .iter()
        .filter_map(|customer| customer.id.strip_prefix("CUS-"))
        .filter_map(|number| number.parse::<u32>().ok())
        .max()
        .unwrap_or(0);

    format!("CUS-{:03}", max_number + 1)
}
