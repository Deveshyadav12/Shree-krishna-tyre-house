use axum::{extract::Form, response::Html};
use serde::Deserialize;

use super::{
    customer_store::customer_store,
    inventory_store::inventory_store,
    job_store::{Job, JobItem, job_store, next_job_id},
};

#[derive(Deserialize)]
pub struct CreateJobForm {
    pub customer: String,
    pub vehicle: String,
    pub vehicle_type: String,
    pub registration: String,
    pub items: String,
    pub notes: String,
}

pub async fn job_new() -> Html<String> {
    let customers = {
        let store = customer_store().lock().unwrap();
        store.clone()
    };

    let tyres = {
        let store = inventory_store().lock().unwrap();
        store.clone()
    };

    let customer_options = customers
        .iter()
        .map(|customer| {
            format!(
                r#"<option value="{}" data-vehicle="{}" data-registration="{}">{}</option>"#,
                customer.id, customer.vehicle, customer.registration, customer.name
            )
        })
        .collect::<Vec<_>>()
        .join("\n");

    let tyre_cards = tyres
        .iter()
        .filter(|tyre| tyre.stock > 0)
        .map(|tyre| {
            format!(
                r#"
                <label class="job-product-card">

                    <input
                        type="checkbox"
                        class="job-tyre"
                        data-id="{}"
                        data-name="{}"
                        data-price="{}"
                    >

                    <div>
                        <strong>{}</strong>
                        <span>{} · Stock: {}</span>
                    </div>

                    <div class="job-price">
                        ₹{}
                    </div>

                    <div class="job-quantity">
                        <button
                            type="button"
                            class="qty-minus"
                        >
                            −
                        </button>

                        <input
                            type="number"
                            class="qty-input"
                            value="1"
                            min="1"
                            max="{}"
                        >

                        <button
                            type="button"
                            class="qty-plus"
                        >
                            +
                        </button>
                    </div>

                </label>
                "#,
                tyre.id,
                tyre.name,
                tyre.price,
                tyre.name,
                tyre.size,
                tyre.stock,
                tyre.price,
                tyre.stock
            )
        })
        .collect::<Vec<_>>()
        .join("");

    let content = format!(
        r#"
        <div class="page-head">

            <div>
                <div class="eyebrow">Job Management</div>

                <h1>Create Job Order</h1>

                <p>
                    Create a new tyre and service job for a customer.
                </p>
            </div>

            <a
                href="/admin/jobs"
                class="btn btn-light"
            >
                Back to Jobs
            </a>

        </div>

        <form
            method="post"
            action="/admin/jobs"
            id="createJobForm"
        >

            <div class="job-form-grid">

                <section class="panel">

                    <div class="panel-head">

                        <div>
                            <h2>Customer & Vehicle</h2>

                            <p>
                                Select an existing customer.
                            </p>
                        </div>

                    </div>

                    <div class="form-grid">

                        <div class="form-group">

                            <label for="jobCustomer">
                                Customer
                            </label>

                            <select
                                id="jobCustomer"
                                name="customer"
                                required
                            >

                                <option value="">
                                    Select customer
                                </option>

                                {}

                            </select>

                        </div>

                        <div class="form-group">

                            <label for="jobVehicle">
                                Vehicle
                            </label>

                            <select
                                id="jobVehicle"
                                name="vehicle"
                                required
                            >

                                <option value="">
                                    Select vehicle
                                </option>

                                <option>Maruti Swift</option>
                                <option>Hyundai Creta</option>
                                <option>Tata Nexon</option>
                                <option>Mahindra Scorpio</option>
                                <option>Honda Activa</option>
                                <option>Maruti Baleno</option>
                                <option>Hyundai i20</option>
                                <option>Tata Punch</option>
                                <option>Mahindra Thar</option>
                                <option>Honda City</option>

                            </select>

                        </div>

                        <div class="form-group">

                            <label for="jobVehicleType">
                                Vehicle Type
                            </label>

                            <select
                                id="jobVehicleType"
                                name="vehicle_type"
                                required
                            >

                                <option value="">
                                    Select vehicle type
                                </option>

                                <option>Passenger Car</option>
                                <option>SUV</option>
                                <option>Sedan</option>
                                <option>Hatchback</option>
                                <option>Two Wheeler</option>
                                <option>Commercial Vehicle</option>

                            </select>

                        </div>

                        <div class="form-group">

                            <label for="jobRegistration">
                                Registration Number
                            </label>

                            <input
                                id="jobRegistration"
                                name="registration"
                                type="text"
                                placeholder="RJ-18-AB-1024"
                                required
                            >

                        </div>

                    </div>

                </section>

                <section class="panel">

                    <div class="panel-head">

                        <div>
                            <h2>Tyres</h2>

                            <p>
                                Select tyres from current inventory.
                            </p>
                        </div>

                        <a
                            href="/admin/inventory/new"
                            class="btn btn-light"
                        >
                            + Add Tyre
                        </a>

                    </div>

                    <div class="job-product-grid">

                        {}

                    </div>

                    <div class="inventory-job-note">
                        Only tyres with available stock are shown.
                    </div>

                </section>

                <section class="panel">

                    <div class="panel-head">

                        <div>
                            <h2>Services</h2>

                            <p>
                                Select required workshop services.
                            </p>
                        </div>

                    </div>

                    <div class="job-service-grid">

                        <label class="job-service-card">

                            <input
                                type="checkbox"
                                class="job-service"
                                data-name="Wheel Alignment"
                                data-price="500"
                            >

                            <span>
                                <strong>
                                    Wheel Alignment
                                </strong>

                                <small>
                                    ₹500
                                </small>
                            </span>

                        </label>

                        <label class="job-service-card">

                            <input
                                type="checkbox"
                                class="job-service"
                                data-name="Wheel Balancing"
                                data-price="400"
                            >

                            <span>
                                <strong>
                                    Wheel Balancing
                                </strong>

                                <small>
                                    ₹400
                                </small>
                            </span>

                        </label>

                        <label class="job-service-card">

                            <input
                                type="checkbox"
                                class="job-service"
                                data-name="Tyre Replacement"
                                data-price="250"
                            >

                            <span>
                                <strong>
                                    Tyre Replacement
                                </strong>

                                <small>
                                    ₹250
                                </small>
                            </span>

                        </label>

                        <label class="job-service-card">

                            <input
                                type="checkbox"
                                class="job-service"
                                data-name="Puncture Repair"
                                data-price="100"
                            >

                            <span>
                                <strong>
                                    Puncture Repair
                                </strong>

                                <small>
                                    ₹100
                                </small>
                            </span>

                        </label>

                        <label class="job-service-card">

                            <input
                                type="checkbox"
                                class="job-service"
                                data-name="Tyre Rotation"
                                data-price="300"
                            >

                            <span>
                                <strong>
                                    Tyre Rotation
                                </strong>

                                <small>
                                    ₹300
                                </small>
                            </span>

                        </label>

                        <label class="job-service-card">

                            <input
                                type="checkbox"
                                class="job-service"
                                data-name="Nitrogen Inflation"
                                data-price="200"
                            >

                            <span>
                                <strong>
                                    Nitrogen Inflation
                                </strong>

                                <small>
                                    ₹200
                                </small>
                            </span>

                        </label>

                    </div>

                </section>

                <section class="panel">

                    <div class="panel-head">

                        <div>
                            <h2>Job Notes</h2>

                            <p>
                                Add workshop instructions or customer requirements.
                            </p>
                        </div>

                    </div>

                    <textarea
                        name="notes"
                        rows="5"
                        placeholder="Example: Replace all four tyres and perform wheel alignment."
                    ></textarea>

                </section>

                <section class="job-summary-panel">

                    <div>
                        <span>Customer</span>
                        <strong id="summaryCustomer">-</strong>
                    </div>

                    <div>
                        <span>Vehicle</span>
                        <strong id="summaryVehicle">-</strong>
                    </div>

                    <div>
                        <span>Tyres</span>
                        <strong id="tyreTotal">₹0</strong>
                    </div>

                    <div>
                        <span>Services</span>
                        <strong id="serviceTotal">₹0</strong>
                    </div>

                    <div class="grand-total">
                        <span>Grand Total</span>
                        <strong id="grandTotal">₹0</strong>
                    </div>

                    <input
                        type="hidden"
                        name="items"
                        id="jobItems"
                        value="[]"
                    >

                    <button
                        type="submit"
                        class="btn btn-primary btn-large"
                    >
                        Create Job Order
                    </button>

                </section>

            </div>

        </form>
        "#,
        customer_options, tyre_cards
    );

    Html(super::layout::admin_page("Create Job Order", &content))
}

pub async fn create_job(Form(form): Form<CreateJobForm>) -> Html<String> {
    let customer_name = {
        let customers = customer_store().lock().unwrap();

        customers
            .iter()
            .find(|customer| customer.id == form.customer)
            .map(|customer| customer.name.clone())
            .unwrap_or_else(|| form.customer.clone())
    };

    let items: Vec<JobItem> = serde_json::from_str(&form.items).unwrap_or_default();

    let total = items
        .iter()
        .map(|item| item.price * item.quantity as u64)
        .sum::<u64>();

    let mut jobs = job_store().lock().unwrap();

    let id = next_job_id(&jobs);

    jobs.push(Job {
        id: id.clone(),
        customer: customer_name,
        vehicle: form.vehicle,
        vehicle_type: form.vehicle_type,
        registration: form.registration,
        items,
        notes: form.notes,
        status: "NEW".to_string(),
        total,
        payment_status: "UNPAID".to_string(),
        payment_method: "-".to_string(),
        invoice_id: "-".to_string(),
    });

    Html(format!(
        r#"
        <!DOCTYPE html>

        <html>

        <head>

            <meta
                http-equiv="refresh"
                content="0;url=/admin/jobs/{id}"
            >

        </head>

        <body>

            <p>
                Job created successfully.
            </p>

        </body>

        </html>
        "#
    ))
}
