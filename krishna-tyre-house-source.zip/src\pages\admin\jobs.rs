use axum::{
    extract::Path,
    response::{Html, Redirect},
};

use super::job_store::job_store;
use super::layout::admin_page;

pub async fn jobs() -> Html<String> {
    let jobs = job_store().lock().unwrap().clone();

    let mut rows = String::new();

    for job in jobs.iter().rev() {
        rows.push_str(&format!(
            r#"
<tr>
    <td>
        <a href="/admin/jobs/{id}" class="job-id-link">
            {id}
        </a>
    </td>

    <td>
        <strong>{customer}</strong>
        <small>{registration}</small>
    </td>

    <td>
        <strong>{vehicle}</strong>
        <small>{vehicle_type}</small>
    </td>

    <td>{items}</td>

    <td>
        <strong>₹{total}</strong>
    </td>

    <td>
        <span class="job-status">
            {status}
        </span>
    </td>

    <td>
        <a href="/admin/jobs/{id}" class="job-view-button">
            View
        </a>
    </td>
</tr>
"#,
            id = job.id,
            customer = job.customer,
            registration = job.registration,
            vehicle = job.vehicle,
            vehicle_type = job.vehicle_type,
            items = job.items.len(),
            total = job.total,
            status = job.status,
        ));
    }

    let content = format!(
        r#"
<div class="admin-page-header">
    <div>
        <div class="admin-eyebrow">OPERATIONS</div>
        <h1>Job Orders</h1>
        <p>Manage tyre work, services and vehicle jobs.</p>
    </div>

    <a href="/admin/jobs/new" class="admin-primary-button">
        + Create Job
    </a>
</div>

<div class="admin-panel">

    <div class="job-admin-toolbar">
        <input
            type="search"
            class="admin-search-input"
            placeholder="Search customer, vehicle or job ID..."
        >

        <select class="admin-filter-select">
            <option>All Status</option>
            <option>NEW</option>
            <option>WORK IN PROGRESS</option>
            <option>COMPLETED</option>
        </select>
    </div>

    <div class="job-admin-table-wrap">

        <table class="job-admin-table">

            <thead>
                <tr>
                    <th>Job ID</th>
                    <th>Customer</th>
                    <th>Vehicle</th>
                    <th>Items</th>
                    <th>Total</th>
                    <th>Status</th>
                    <th>Action</th>
                </tr>
            </thead>

            <tbody>
                {rows}
            </tbody>

        </table>

    </div>

</div>
"#
    );

    Html(admin_page("Job Orders", &content))
}

pub async fn job_detail(Path(id): Path<String>) -> Html<String> {
    let job = {
        let jobs = job_store().lock().unwrap();

        jobs.iter().find(|job| job.id == id).cloned()
    };

    match job {
        Some(job) => {
            let mut items_html = String::new();

            for item in &job.items {
                let subtotal = item.price * item.quantity as u64;

                items_html.push_str(&format!(
                    r#"
<tr>
    <td>{name}</td>
    <td>{item_type}</td>
    <td>{quantity}</td>
    <td>₹{price}</td>
    <td>₹{subtotal}</td>
</tr>
"#,
                    name = item.name,
                    item_type = item.item_type,
                    quantity = item.quantity,
                    price = item.price,
                    subtotal = subtotal,
                ));
            }

            let action = if job.status == "NEW" {
                format!(
                    r#"
<form method="post" action="/admin/jobs/{}/start">
    <button
        type="submit"
        class="job-action-button job-start-button"
    >
        Start Job
    </button>
</form>
"#,
                    job.id
                )
            } else if job.status == "WORK IN PROGRESS" {
                format!(
                    r#"
<form method="post" action="/admin/jobs/{}/complete">
    <button
        type="submit"
        class="job-action-button job-complete-button"
    >
        Mark Completed
    </button>
</form>
"#,
                    job.id
                )
            } else {
                r#"
<div class="job-completed-message">
    Job Completed
</div>
"#
                .to_string()
            };

            let content = format!(
                r#"
<div class="admin-page-header">

    <div>
        <div class="admin-eyebrow">JOB ORDER</div>

        <h1>{id}</h1>

        <p>
            {customer} - {vehicle}
        </p>
    </div>

    <div class="job-detail-actions">

        <a
            href="/admin/jobs"
            class="admin-secondary-button"
        >
            Back to Jobs
        </a>

        {action}

    </div>

</div>


<div class="job-detail-grid">

    <div>

        <div class="admin-panel">

            <div class="admin-panel-header">

                <div>
                    <h2>Job Items</h2>
                    <p>
                        Tyres and services included in this job.
                    </p>
                </div>

                <span class="job-status">
                    {status}
                </span>

            </div>


            <div class="job-admin-table-wrap">

                <table class="job-admin-table">

                    <thead>
                        <tr>
                            <th>Item</th>
                            <th>Type</th>
                            <th>Quantity</th>
                            <th>Price</th>
                            <th>Subtotal</th>
                        </tr>
                    </thead>

                    <tbody>
                        {items_html}
                    </tbody>

                </table>

            </div>

        </div>


        <div class="admin-panel">

            <div class="admin-panel-header">
                <div>
                    <h2>Job Notes</h2>
                </div>
            </div>

            <div class="job-notes-box">
                {notes}
            </div>

        </div>

    </div>


    <div>

        <div class="job-detail-card">

            <div class="job-detail-card-header">
                Customer
            </div>

            <strong>{customer}</strong>

            <small>{registration}</small>

        </div>


        <div class="job-detail-card">

            <div class="job-detail-card-header">
                Vehicle
            </div>

            <strong>{vehicle}</strong>

            <small>{vehicle_type}</small>

            <small>{registration}</small>

        </div>


        <div class="job-detail-card job-total-card">

            <span>Estimated Total</span>

            <strong>₹{total}</strong>

        </div>

    </div>

</div>
"#,
                id = job.id,
                customer = job.customer,
                vehicle = job.vehicle,
                registration = job.registration,
                vehicle_type = job.vehicle_type,
                status = job.status,
                notes = if job.notes.is_empty() {
                    "No notes added."
                } else {
                    &job.notes
                },
                total = job.total,
                items_html = items_html,
                action = action,
            );

            Html(admin_page("Job Orders", &content))
        }

        None => Html(admin_page(
            "Job Orders",
            r#"
<div class="admin-page-header">
    <div>
        <div class="admin-eyebrow">JOB ORDER</div>
        <h1>Job Not Found</h1>
        <p>The requested job does not exist.</p>
    </div>
</div>

<div class="admin-panel">

    <a
        href="/admin/jobs"
        class="admin-secondary-button"
    >
        Back to Jobs
    </a>

</div>
"#,
        )),
    }
}

pub async fn start_job(Path(id): Path<String>) -> Redirect {
    let mut jobs = job_store().lock().unwrap();

    if let Some(job) = jobs.iter_mut().find(|job| job.id == id) {
        if job.status == "NEW" {
            job.status = "WORK IN PROGRESS".to_string();
        }
    }

    Redirect::to(&format!("/admin/jobs/{}", id))
}

pub async fn complete_job(Path(id): Path<String>) -> Redirect {
    let mut jobs = job_store().lock().unwrap();

    if let Some(job) = jobs.iter_mut().find(|job| job.id == id) {
        if job.status == "WORK IN PROGRESS" {
            job.status = "COMPLETED".to_string();
        }
    }

    Redirect::to(&format!("/admin/jobs/{}", id))
}
