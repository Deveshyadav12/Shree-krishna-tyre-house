﻿use axum::{
    extract::{Form, Path, State},
    response::{Html, Redirect},
};
use sqlx::Row;

use crate::AppState;

#[derive(serde::Deserialize)]
pub struct InventoryForm {
    pub name: String,
    pub brand: String,
    pub size: String,
    pub tyre_type: String,
    pub price: i64,
    pub stock: i32,
    pub low_stock_limit: i32,
}

#[derive(serde::Deserialize)]
pub struct StockForm {
    pub movement_type: String,
    pub quantity: i32,
    pub notes: String,
}

pub async fn inventory(
    State(state): State<AppState>,
) -> Html<String> {
    let rows = match sqlx::query(
        r#"
        SELECT id, name, brand, size, tyre_type, price, stock, low_stock_limit
        FROM inventory
        ORDER BY created_at DESC
        "#
    )
    .fetch_all(&state.pool)
    .await
    {
        Ok(rows) => rows,
        Err(error) => {
            eprintln!("Inventory query failed: {}", error);
            return Html(error_page("Unable to load inventory."));
        }
    };

    let mut body = String::new();

    body.push_str(
        r#"
        <div class="page-header">
            <div>
                <h1>Tyre Inventory</h1>
                <p>Manage tyre stock, pricing and inventory levels.</p>
            </div>
            <a href="/admin/inventory/new" class="btn btn-primary">
                Add Tyre
            </a>
        </div>

        <div class="table-card">
            <table class="data-table">
                <thead>
                    <tr>
                        <th>Tyre</th>
                        <th>Brand</th>
                        <th>Size</th>
                        <th>Type</th>
                        <th>Price</th>
                        <th>Stock</th>
                        <th>Status</th>
                        <th>Action</th>
                    </tr>
                </thead>
                <tbody>
        "#,
    );

    for item in rows {
        let id: String = item.get("id");
        let name: String = item.get("name");
        let brand: String = item.get("brand");
        let size: String = item.get("size");
        let tyre_type: String = item.get("tyre_type");
        let price: i64 = item.get("price");
        let stock: i32 = item.get("stock");
        let low_stock_limit: i32 = item.get("low_stock_limit");

        let stock_class = if stock <= low_stock_limit {
            "stock-low"
        } else {
            "stock-ok"
        };

        let status = if stock <= low_stock_limit {
            "Low Stock"
        } else {
            "In Stock"
        };

        body.push_str(&format!(
            r#"
            <tr>
                <td>
                    <strong>{}</strong>
                </td>
                <td>{}</td>
                <td>{}</td>
                <td>{}</td>
                <td>Rs. {}</td>
                <td>{}</td>
                <td>
                    <span class="{}">{}</span>
                </td>
                <td>
                    <a href="/admin/inventory/{}" class="table-link">
                        View
                    </a>
                </td>
            </tr>
            "#,
            escape_html(&name),
            escape_html(&brand),
            escape_html(&size),
            escape_html(&tyre_type),
            price,
            stock,
            stock_class,
            status,
            id
        ));
    }

    body.push_str(
        r#"
                </tbody>
            </table>
        </div>
        "#,
    );

    Html(page("Tyre Inventory", body))
}

pub async fn inventory_detail(
    State(state): State<AppState>,
    Path(id): Path<String>,
) -> Html<String> {
    let item = match sqlx::query(
        r#"
        SELECT id, name, brand, size, tyre_type, price, stock, low_stock_limit
        FROM inventory
        WHERE id = $1
        "#
    )
    .bind(&id)
    .fetch_optional(&state.pool)
    .await
    {
        Ok(item) => item,
        Err(error) => {
            eprintln!("Inventory detail query failed: {}", error);
            return Html(error_page("Unable to load inventory item."));
        }
    };

    let Some(item) = item else {
        return Html(error_page("Inventory item not found."));
    };

    let item_id: String = item.get("id");
    let name: String = item.get("name");
    let brand: String = item.get("brand");
    let size: String = item.get("size");
    let tyre_type: String = item.get("tyre_type");
    let price: i64 = item.get("price");
    let stock: i32 = item.get("stock");
    let low_stock_limit: i32 = item.get("low_stock_limit");

    let value = price * stock as i64;

    let status = if stock <= low_stock_limit {
        "Low Stock"
    } else {
        "In Stock"
    };

    let body = format!(
        r#"
        <div class="page-header">
            <div>
                <h1>{}</h1>
                <p>Inventory details</p>
            </div>

            <div class="page-actions">
                <a href="/admin/inventory/{}/edit" class="btn btn-primary">
                    Edit Tyre
                </a>
                <a href="/admin/inventory" class="btn btn-secondary">
                    Back
                </a>
            </div>
        </div>

        <div class="detail-grid">
            <div class="panel">
                <h2>Tyre Information</h2>

                <div class="detail-row">
                    <span>Brand</span>
                    <strong>{}</strong>
                </div>

                <div class="detail-row">
                    <span>Size</span>
                    <strong>{}</strong>
                </div>

                <div class="detail-row">
                    <span>Type</span>
                    <strong>{}</strong>
                </div>

                <div class="detail-row">
                    <span>Price</span>
                    <strong>Rs. {}</strong>
                </div>
            </div>

            <div class="panel">
                <h2>Stock Information</h2>

                <div class="detail-row">
                    <span>Current Stock</span>
                    <strong>{}</strong>
                </div>

                <div class="detail-row">
                    <span>Low Stock Limit</span>
                    <strong>{}</strong>
                </div>

                <div class="detail-row">
                    <span>Status</span>
                    <strong>{}</strong>
                </div>

                <div class="detail-row">
                    <span>Inventory Value</span>
                    <strong>Rs. {}</strong>
                </div>
            </div>
        </div>

        <div class="panel">
            <h2>Stock Adjustment</h2>

            <form method="post" action="/admin/inventory/{}/adjust" class="form-grid">
                <div class="form-group">
                    <label>Movement Type</label>
                    <select name="movement_type" required>
                        <option value="Stock In">Stock In</option>
                        <option value="Stock Out">Stock Out</option>
                        <option value="Adjustment">Adjustment</option>
                    </select>
                </div>

                <div class="form-group">
                    <label>Quantity</label>
                    <input type="number" name="quantity" min="1" required>
                </div>

                <div class="form-group form-full">
                    <label>Notes</label>
                    <textarea name="notes" rows="3"></textarea>
                </div>

                <div>
                    <button type="submit" class="btn btn-primary">
                        Update Stock
                    </button>
                </div>
            </form>
        </div>
        "#,
        escape_html(&name),
        item_id,
        escape_html(&brand),
        escape_html(&size),
        escape_html(&tyre_type),
        price,
        stock,
        low_stock_limit,
        status,
        value,
        item_id
    );

    Html(page(&name, body))
}

pub async fn inventory_edit(
    State(state): State<AppState>,
    Path(id): Path<String>,
) -> Html<String> {
    let item = match sqlx::query(
        r#"
        SELECT id, name, brand, size, tyre_type, price, stock, low_stock_limit
        FROM inventory
        WHERE id = $1
        "#
    )
    .bind(&id)
    .fetch_optional(&state.pool)
    .await
    {
        Ok(item) => item,
        Err(error) => {
            eprintln!("Inventory edit query failed: {}", error);
            return Html(error_page("Unable to load inventory item."));
        }
    };

    let Some(item) = item else {
        return Html(error_page("Inventory item not found."));
    };

    let item_id: String = item.get("id");
    let name: String = item.get("name");
    let brand: String = item.get("brand");
    let size: String = item.get("size");
    let tyre_type: String = item.get("tyre_type");
    let price: i64 = item.get("price");
    let stock: i32 = item.get("stock");
    let low_stock_limit: i32 = item.get("low_stock_limit");

    let body = format!(
        r#"
        <div class="page-header">
            <div>
                <h1>Edit Tyre</h1>
                <p>Update inventory information.</p>
            </div>
        </div>

        <div class="panel">
            <form method="post" action="/admin/inventory/{}/edit" class="form-grid">

                <div class="form-group">
                    <label>Tyre Name</label>
                    <input type="text" name="name" value="{}" required>
                </div>

                <div class="form-group">
                    <label>Brand</label>
                    <input type="text" name="brand" value="{}" required>
                </div>

                <div class="form-group">
                    <label>Size</label>
                    <input type="text" name="size" value="{}" required>
                </div>

                <div class="form-group">
                    <label>Tyre Type</label>
                    <input type="text" name="tyre_type" value="{}" required>
                </div>

                <div class="form-group">
                    <label>Price</label>
                    <input type="number" name="price" value="{}" min="0" required>
                </div>

                <div class="form-group">
                    <label>Stock</label>
                    <input type="number" name="stock" value="{}" min="0" required>
                </div>

                <div class="form-group">
                    <label>Low Stock Limit</label>
                    <input type="number" name="low_stock_limit" value="{}" min="0" required>
                </div>

                <div class="form-actions">
                    <button type="submit" class="btn btn-primary">
                        Save Changes
                    </button>

                    <a href="/admin/inventory/{}" class="btn btn-secondary">
                        Cancel
                    </a>
                </div>
            </form>
        </div>
        "#,
        item_id,
        escape_html(&name),
        escape_html(&brand),
        escape_html(&size),
        escape_html(&tyre_type),
        price,
        stock,
        low_stock_limit,
        item_id
    );

    Html(page("Edit Tyre", body))
}

pub async fn update_inventory(
    State(state): State<AppState>,
    Path(id): Path<String>,
    Form(form): Form<InventoryForm>,
) -> Redirect {
    let result = sqlx::query(
        r#"
        UPDATE inventory
        SET name = $1,
            brand = $2,
            size = $3,
            tyre_type = $4,
            price = $5,
            stock = $6,
            low_stock_limit = $7,
            updated_at = NOW()
        WHERE id = $8
        "#
    )
    .bind(&form.name)
    .bind(&form.brand)
    .bind(&form.size)
    .bind(&form.tyre_type)
    .bind(form.price)
    .bind(form.stock)
    .bind(form.low_stock_limit)
    .bind(&id)
    .execute(&state.pool)
    .await;

    if let Err(error) = result {
        eprintln!("Inventory update failed: {}", error);
    }

    Redirect::to(&format!("/admin/inventory/{}", id))
}

pub async fn adjust_stock(
    State(state): State<AppState>,
    Path(id): Path<String>,
    Form(form): Form<StockForm>,
) -> Redirect {
    let mut transaction = match state.pool.begin().await {
        Ok(transaction) => transaction,
        Err(error) => {
            eprintln!("Transaction start failed: {}", error);
            return Redirect::to(&format!("/admin/inventory/{}", id));
        }
    };

    let item = match sqlx::query(
        r#"
        SELECT name, stock
        FROM inventory
        WHERE id = $1
        FOR UPDATE
        "#
    )
    .bind(&id)
    .fetch_optional(&mut *transaction)
    .await
    {
        Ok(item) => item,
        Err(error) => {
            eprintln!("Stock lookup failed: {}", error);
            return Redirect::to(&format!("/admin/inventory/{}", id));
        }
    };

    let Some(item) = item else {
        return Redirect::to("/admin/inventory");
    };

    let item_name: String = item.get("name");
    let stock_before: i32 = item.get("stock");

    let stock_after = match form.movement_type.as_str() {
        "Stock In" => stock_before + form.quantity,
        "Stock Out" => (stock_before - form.quantity).max(0),
        "Adjustment" => form.quantity,
        _ => stock_before,
    };

    let _ = sqlx::query(
        r#"
        UPDATE inventory
        SET stock = $1,
            updated_at = NOW()
        WHERE id = $2
        "#
    )
    .bind(stock_after)
    .bind(&id)
    .execute(&mut *transaction)
    .await;

    let movement_id = format!(
        "STK-{}",
        chrono::Utc::now().timestamp_millis()
    );

    let _ = sqlx::query(
        r#"
        INSERT INTO stock_movements
        (
            id,
            tyre_id,
            tyre_name,
            movement_type,
            quantity,
            stock_before,
            stock_after,
            reference,
            notes
        )
        VALUES ($1,$2,$3,$4,$5,$6,$7,$8,$9)
        "#
    )
    .bind(&movement_id)
    .bind(&id)
    .bind(&item_name)
    .bind(&form.movement_type)
    .bind(form.quantity)
    .bind(stock_before)
    .bind(stock_after)
    .bind("")
    .bind(&form.notes)
    .execute(&mut *transaction)
    .await;

    if let Err(error) = transaction.commit().await {
        eprintln!("Stock transaction commit failed: {}", error);
    }

    Redirect::to(&format!("/admin/inventory/{}", id))
}

fn page(title: &str, body: String) -> String {
    format!(
        r#"<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>{} - Shri Krishna Tyre House</title>
    <link rel="stylesheet" href="/assets/css/admin.css">
</head>
<body>
    <div class="admin-shell">
        {}
    </div>
</body>
</html>"#,
        escape_html(title),
        body
    )
}

fn error_page(message: &str) -> String {
    page(
        "Error",
        format!(
            r#"
            <div class="panel">
                <h1>Error</h1>
                <p>{}</p>
                <a href="/admin/inventory" class="btn btn-primary">
                    Back to Inventory
                </a>
            </div>
            "#,
            escape_html(message)
        ),
    )
}

fn escape_html(value: &str) -> String {
    value
        .replace('&', "&amp;")
        .replace('<', "&lt;")
        .replace('>', "&gt;")
        .replace('"', "&quot;")
        .replace('\'', "&#39;")
}
