use axum::response::Html;

use super::layout::page;

pub async fn home() -> Html<String> {
    let content = r#"

<section class="hero">

    <div class="hero-background"></div>

    <div class="container hero-content">

        <div class="hero-text">

            <span class="eyebrow">
                TRUSTED TYRE & AUTO SERVICE
            </span>

            <h1>
                Drive With
                <span>Confidence.</span>
            </h1>

            <p>
                Premium tyres and professional vehicle services
                for a safer, smoother and more confident drive.
            </p>

            <div class="hero-actions">

                <a href="/tyres" class="btn btn-primary">
                    Explore Tyres
                </a>

                <a href="/services" class="btn btn-outline">
                    View Services
                </a>

            </div>

        </div>

        <div class="hero-card">

            <div class="hero-card-icon">
                ◎
            </div>

            <h3>
                Professional Tyre Care
            </h3>

            <p>
                Quality products and reliable service
                for your vehicle.
            </p>

            <div class="hero-card-line"></div>

            <span>
                Shri Krishna Tyre House
            </span>

        </div>

    </div>

</section>


<section class="search-section">

    <div class="container">

        <div class="section-heading center">

            <span class="eyebrow">
                FIND YOUR TYRES
            </span>

            <h2>
                Find The Right Tyre
            </h2>

            <p>
                Search tyres by vehicle type, tyre size or brand.
            </p>

        </div>

        <form class="tyre-search" action="/tyres" method="get">

            <div class="search-field">

                <label for="vehicle">
                    Vehicle Type
                </label>

                <select id="vehicle" name="vehicle">

                    <option value="">
                        Select Vehicle
                    </option>

                    <option value="car">
                        Car
                    </option>

                    <option value="suv">
                        SUV
                    </option>

                    <option value="bike">
                        Bike
                    </option>

                    <option value="scooter">
                        Scooter
                    </option>

                    <option value="commercial">
                        Commercial
                    </option>

                </select>

            </div>


            <div class="search-field">

                <label for="size">
                    Tyre Size
                </label>

                <input
                    id="size"
                    name="size"
                    type="text"
                    placeholder="Example: 185/65 R15"
                >

            </div>


            <div class="search-field">

                <label for="brand">
                    Brand
                </label>

                <select id="brand" name="brand">

                    <option value="">
                        All Brands
                    </option>

                    <option value="mrf">
                        MRF
                    </option>

                    <option value="ceat">
                        CEAT
                    </option>

                    <option value="apollo">
                        Apollo
                    </option>

                    <option value="jk">
                        JK Tyre
                    </option>

                    <option value="michelin">
                        Michelin
                    </option>

                    <option value="bridgestone">
                        Bridgestone
                    </option>

                </select>

            </div>


            <button
                type="submit"
                class="btn btn-primary search-button"
            >
                Search Tyres
            </button>

        </form>

    </div>

</section>


<section class="section">

    <div class="container">

        <div class="section-heading">

            <div>

                <span class="eyebrow">
                    FEATURED PRODUCTS
                </span>

                <h2>
                    Popular Tyres
                </h2>

            </div>

            <a href="/tyres" class="text-link">
                View All Tyres →
            </a>

        </div>


        <div class="product-grid">

            <article class="product-card">

                <div class="product-image">
                    <div class="tyre-placeholder">
                        TYRE
                    </div>
                </div>

                <div class="product-content">

                    <span class="product-brand">
                        MRF
                    </span>

                    <h3>
                        MRF ZVTV
                    </h3>

                    <p>
                        Premium passenger car tyre.
                    </p>

                    <div class="product-meta">
                        <span>185/65 R15</span>
                        <strong>₹6,250</strong>
                    </div>

                    <a href="/tyres/1" class="product-button">
                        View Details
                    </a>

                </div>

            </article>


            <article class="product-card">

                <div class="product-image">
                    <div class="tyre-placeholder">
                        TYRE
                    </div>
                </div>

                <div class="product-content">

                    <span class="product-brand">
                        CEAT
                    </span>

                    <h3>
                        CEAT Milaze
                    </h3>

                    <p>
                        Long-lasting performance tyre.
                    </p>

                    <div class="product-meta">
                        <span>175/65 R14</span>
                        <strong>₹5,850</strong>
                    </div>

                    <a href="/tyres/2" class="product-button">
                        View Details
                    </a>

                </div>

            </article>


            <article class="product-card">

                <div class="product-image">
                    <div class="tyre-placeholder">
                        TYRE
                    </div>
                </div>

                <div class="product-content">

                    <span class="product-brand">
                        APOLLO
                    </span>

                    <h3>
                        Apollo Amazer
                    </h3>

                    <p>
                        Balanced comfort and performance.
                    </p>

                    <div class="product-meta">
                        <span>195/65 R15</span>
                        <strong>₹6,900</strong>
                    </div>

                    <a href="/tyres/3" class="product-button">
                        View Details
                    </a>

                </div>

            </article>

        </div>

    </div>

</section>


<section class="section section-dark">

    <div class="container">

        <div class="section-heading center">

            <span class="eyebrow">
                OUR SERVICES
            </span>

            <h2>
                Complete Tyre Care
            </h2>

            <p>
                Professional services to keep your vehicle
                performing at its best.
            </p>

        </div>


        <div class="service-grid">

            <article class="service-card">
                <div class="service-icon">◉</div>

                <h3>
                    Wheel Alignment
                </h3>

                <p>
                    Accurate alignment for better handling
                    and tyre life.
                </p>

                <a href="/services">
                    Learn More →
                </a>
            </article>


            <article class="service-card">
                <div class="service-icon">◎</div>

                <h3>
                    Wheel Balancing
                </h3>

                <p>
                    Reduce vibration and improve driving comfort.
                </p>

                <a href="/services">
                    Learn More →
                </a>
            </article>


            <article class="service-card">
                <div class="service-icon">◌</div>

                <h3>
                    Tyre Replacement
                </h3>

                <p>
                    Professional tyre replacement for your vehicle.
                </p>

                <a href="/services">
                    Learn More →
                </a>
            </article>


            <article class="service-card">
                <div class="service-icon">+</div>

                <h3>
                    Puncture Repair
                </h3>

                <p>
                    Reliable puncture and tubeless service.
                </p>

                <a href="/services">
                    Learn More →
                </a>
            </article>

        </div>

    </div>

</section>


<section class="section">

    <div class="container">

        <div class="section-heading center">

            <span class="eyebrow">
                BRANDS
            </span>

            <h2>
                Trusted Tyre Brands
            </h2>

        </div>


        <div class="brand-grid">

            <div class="brand-box">MRF</div>
            <div class="brand-box">CEAT</div>
            <div class="brand-box">APOLLO</div>
            <div class="brand-box">JK TYRE</div>
            <div class="brand-box">MICHELIN</div>
            <div class="brand-box">BRIDGESTONE</div>

        </div>

    </div>

</section>


<section class="about-preview">

    <div class="container about-grid">

        <div class="about-image">

            <div class="image-placeholder">
                SHRI KRISHNA<br>
                TYRE HOUSE
            </div>

        </div>


        <div class="about-content">

            <span class="eyebrow">
                ABOUT US
            </span>

            <h2>
                Your Trusted Tyre Partner
            </h2>

            <p>
                Shri Krishna Tyre House provides quality tyres
                and professional tyre care services for customers
                looking for reliable vehicle performance.
            </p>

            <p>
                From tyre selection to alignment, balancing,
                puncture repair and tyre care, our focus is on
                dependable service and customer satisfaction.
            </p>

            <a href="/about" class="btn btn-primary">
                Learn About Us
            </a>

        </div>

    </div>

</section>


<section class="contact-strip">

    <div class="container contact-strip-content">

        <div>

            <span class="eyebrow">
                VISIT OUR STORE
            </span>

            <h2>
                Ready For Your Next Drive?
            </h2>

            <p>
                Singhana Road, Buhana, Jhunjhunu,
                Rajasthan 333502
            </p>

        </div>

        <a href="/contact" class="btn btn-light">
            Contact Us
        </a>

    </div>

</section>

"#;

    Html(page("Home", content))
}
