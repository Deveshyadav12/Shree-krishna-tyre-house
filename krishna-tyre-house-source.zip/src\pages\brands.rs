use axum::{extract::Path, response::Html};

use super::layout::page;

pub async fn brands() -> Html<String> {
    let brands = vec![
        (
            "MRF",
            "mrf",
            "MRF tyres for everyday driving and multiple vehicle applications.",
        ),
        (
            "CEAT",
            "ceat",
            "CEAT tyre options focused on everyday performance and durability.",
        ),
        (
            "Apollo",
            "apollo",
            "Apollo tyres for passenger vehicles and multiple applications.",
        ),
        (
            "JK Tyre",
            "jk-tyre",
            "JK Tyre options for passenger, SUV and commercial applications.",
        ),
        (
            "Michelin",
            "michelin",
            "Michelin tyre options for selected vehicle applications.",
        ),
        (
            "Bridgestone",
            "bridgestone",
            "Bridgestone tyres for different passenger vehicle requirements.",
        ),
    ];

    let mut brand_cards = String::new();

    for (name, slug, description) in brands {
        brand_cards.push_str(&format!(
            r#"
            <article class="brand-showcase">

                <div class="brand-logo-large">
                    {name}
                </div>

                <span
                    class="eyebrow"
                    style="margin-top:24px;"
                >
                    TYRE BRAND
                </span>

                <h2>
                    {name}
                </h2>

                <p>
                    {description}
                </p>

                <a href="/brands/{slug}">
                    Explore {name} Tyres →
                </a>

            </article>
            "#
        ));
    }

    let content = format!(
        r#"

        <section class="page-hero">

            <div class="container">

                <span class="eyebrow">
                    OUR BRANDS
                </span>

                <h1>
                    Trusted Tyre Brands
                </h1>

                <p>
                    Explore tyre options from leading tyre brands
                    available through Shri Krishna Tyre House.
                </p>

            </div>

        </section>


        <section class="section">

            <div class="container">

                <div class="section-heading">

                    <div>

                        <span class="eyebrow">
                            BRANDS
                        </span>

                        <h2>
                            Explore Our Tyre Brands
                        </h2>

                        <p>
                            Select a brand to explore its tyre options.
                        </p>

                    </div>

                </div>


                <div class="brand-showcase-grid">

                    {}

                </div>

            </div>

        </section>


        <section class="contact-strip">

            <div class="container">

                <div class="contact-strip-content">

                    <div>

                        <span class="eyebrow">
                            NEED HELP?
                        </span>

                        <h2>
                            Need Help Choosing A Tyre?
                        </h2>

                        <p>
                            Contact Shri Krishna Tyre House
                            for tyre information and support.
                        </p>

                    </div>

                    <a
                        href="/contact"
                        class="btn btn-light"
                    >
                        Contact Us →
                    </a>

                </div>

            </div>

        </section>

        "#,
        brand_cards
    );

    Html(page("Brands", &content))
}

pub async fn brand_detail(Path(slug): Path<String>) -> Html<String> {
    let brand = match slug.as_str() {
        "mrf" => (
            "MRF",
            "MRF tyres for passenger vehicles and everyday driving.",
            vec![
                ("MRF ZVTV", "185/65 R15", "Passenger Car", "₹6,250"),
                ("MRF ZLX", "195/65 R15", "Passenger Car", "₹7,150"),
                ("MRF Wanderer", "215/65 R16", "SUV", "₹8,650"),
            ],
        ),

        "ceat" => (
            "CEAT",
            "CEAT tyre options for everyday performance and durability.",
            vec![
                ("CEAT Milaze", "175/65 R14", "Passenger Car", "₹5,850"),
                ("CEAT SecuraDrive", "185/65 R15", "Passenger Car", "₹6,450"),
                ("CEAT SportDrive", "205/55 R16", "Passenger Car", "₹8,150"),
            ],
        ),

        "apollo" => (
            "Apollo",
            "Apollo tyres for passenger vehicles and multiple applications.",
            vec![
                ("Apollo Amazer", "195/65 R15", "Passenger Car", "₹6,900"),
                ("Apollo Alnac", "205/55 R16", "Passenger Car", "₹8,250"),
                ("Apollo Apterra", "215/65 R16", "SUV", "₹8,750"),
            ],
        ),

        "jk-tyre" => (
            "JK Tyre",
            "JK Tyre options for passenger, SUV and commercial applications.",
            vec![
                ("JK Ranger", "215/65 R16", "SUV", "₹8,400"),
                ("JK UX Royale", "185/65 R15", "Passenger Car", "₹6,300"),
                ("JK Vectra", "195/65 R15", "Passenger Car", "₹6,750"),
            ],
        ),

        "michelin" => (
            "Michelin",
            "Michelin tyre options for selected vehicle applications.",
            vec![
                ("Michelin Street", "90/90-18", "Motorcycle", "₹2,750"),
                ("Michelin Energy", "195/65 R15", "Passenger Car", "₹9,100"),
                ("Michelin Primacy", "205/55 R16", "Passenger Car", "₹10,250"),
            ],
        ),

        "bridgestone" => (
            "Bridgestone",
            "Bridgestone tyres for different passenger vehicle requirements.",
            vec![
                (
                    "Bridgestone Turanza",
                    "205/55 R16",
                    "Passenger Car",
                    "₹9,250",
                ),
                (
                    "Bridgestone Ecopia",
                    "185/65 R15",
                    "Passenger Car",
                    "₹7,450",
                ),
                ("Bridgestone Dueler", "215/65 R16", "SUV", "₹9,150"),
            ],
        ),

        _ => (
            "Tyre Brand",
            "Explore tyre products from Shri Krishna Tyre House.",
            vec![],
        ),
    };

    let mut product_cards = String::new();

    for (name, size, vehicle, price) in brand.2 {
        product_cards.push_str(&format!(
            r#"
            <article class="product-card">

                <div class="product-image">

                    <div class="tyre-placeholder">
                        TYRE
                    </div>

                </div>

                <div class="product-content">

                    <div class="product-brand">
                        {brand}
                    </div>

                    <h3>
                        {name}
                    </h3>

                    <p>
                        {vehicle}
                    </p>

                    <div class="product-meta">

                        <span>
                            {size}
                        </span>

                        <strong>
                            {price}
                        </strong>

                    </div>

                    <a
                        href="/contact"
                        class="product-button"
                    >
                        Enquire About Tyre →
                    </a>

                </div>

            </article>
            "#,
            brand = brand.0,
        ));
    }

    let content = format!(
        r#"

        <section class="page-hero">

            <div class="container">

                <span class="eyebrow">
                    TYRE BRAND
                </span>

                <h1>
                    {brand}
                </h1>

                <p>
                    {description}
                </p>

            </div>

        </section>


        <section class="section">

            <div class="container">

                <div class="catalog-header">

                    <div>

                        <span class="eyebrow">
                            {brand} TYRES
                        </span>

                        <h2>
                            Available Options
                        </h2>

                    </div>

                    <a
                        href="/tyres"
                        class="btn btn-primary"
                    >
                        View All Tyres
                    </a>

                </div>


                <div class="product-grid">

                    {products}

                </div>

            </div>

        </section>


        <section class="section section-dark">

            <div class="container">

                <div class="section-heading">

                    <div>

                        <span class="eyebrow">
                            SHRI KRISHNA TYRE HOUSE
                        </span>

                        <h2>
                            Need Help Selecting A Tyre?
                        </h2>

                        <p>
                            Contact our store for tyre information,
                            availability and service enquiries.
                        </p>

                    </div>

                    <a
                        href="/contact"
                        class="btn btn-primary"
                    >
                        Contact Store
                    </a>

                </div>

            </div>

        </section>

        "#,
        brand = brand.0,
        description = brand.1,
        products = product_cards,
    );

    Html(page(&format!("{} Tyres", brand.0), &content))
}
