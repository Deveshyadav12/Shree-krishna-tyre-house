﻿use axum::{
    routing::{get, post},
    Router,
};

use crate::{
    pages::{about, admin, brands, contact, home, services, tyres},
    AppState,
};

pub fn public_routes() -> Router<AppState> {
    Router::new()
        .route("/", get(home::home))
        .route("/tyres", get(tyres::tyres))
        .route("/tyres/{id}", get(tyres::tyre_detail))
        .route("/services", get(services::services))
        .route("/brands", get(brands::brands))
        .route("/brands/{slug}", get(brands::brand_detail))
        .route("/about", get(about::about))
        .route("/contact", get(contact::contact))

        .route(
            "/admin/login",
            get(admin::login::login)
                .post(admin::login::login_submit),
        )

        .route("/admin", get(admin::dashboard::dashboard))

        .route(
            "/admin/inventory",
            get(admin::inventory::inventory),
        )
        .route(
            "/admin/inventory/{id}",
            get(admin::inventory::inventory_detail),
        )
        .route(
            "/admin/inventory/{id}/edit",
            get(admin::inventory::inventory_edit)
                .post(admin::inventory::update_inventory),
        )
        .route(
            "/admin/inventory/{id}/adjust",
            post(admin::inventory::adjust_stock),
        )
        .route(
            "/admin/inventory/new",
            get(admin::inventory_new::inventory_new)
                .post(admin::inventory_new::create_inventory),
        )
        .route(
            "/admin/inventory/history",
            get(admin::stock_history::stock_history),
        )

        .route(
            "/admin/services",
            get(admin::services::services),
        )

        .route(
            "/admin/brands",
            get(admin::brands::brands),
        )

        .route(
            "/admin/customers",
            get(admin::customers::customers),
        )
        .route(
            "/admin/customers/new",
            get(admin::customer_new::customer_new)
                .post(admin::customer_new::create_customer),
        )
        .route(
            "/admin/customers/{id}",
            get(admin::customers::customer_detail),
        )

        .route(
            "/admin/jobs",
            get(admin::jobs::jobs)
                .post(admin::job_new::create_job),
        )
        .route(
            "/admin/jobs/new",
            get(admin::job_new::job_new),
        )
        .route(
            "/admin/jobs/{id}",
            get(admin::jobs::job_detail),
        )
        .route(
            "/admin/jobs/{id}/start",
            post(admin::jobs::start_job),
        )
        .route(
            "/admin/jobs/{id}/complete",
            post(admin::jobs::complete_job),
        )

        .route(
            "/admin/billing",
            get(admin::billing::billing),
        )
        .route(
            "/admin/billing/{id}",
            get(admin::billing::bill_detail),
        )
        .route(
            "/admin/billing/{id}/pay",
            post(admin::billing::process_payment),
        )

        .route(
            "/admin/invoices",
            get(admin::invoices::invoices),
        )
        .route(
            "/admin/invoices/{id}",
            get(admin::invoices::invoice_detail),
        )
}
